﻿/************************************************************ 
* Author: Justin Urbany 
* Last edited: January 18, 2018 
*  
* This class is the entry point of the app it will gives user 
* the option to login with an username and password or create  
* an account. 
*  
*  
* Parameters: None 
*  
* Returns: If username and password are correct then it will send 
* back a userid and if incorrect it will send a message that username 
* or password is incorrect 
*  
*************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Xamarin.Forms;

namespace CertiTracker
{
    public class Login : ContentPage
    {
        Entry m_userName;
        Entry m_password;
        Button m_loginButton;
        Button m_signUp;
        App m_certiTracker;
        public Login(App certiTricker)
        {
            m_certiTracker = certiTricker;
            m_userName = new Entry() { Placeholder = "UserName" };
            m_userName.Margin = new Thickness(10, 0, 10, 0);

            m_password = new Entry() { Placeholder = "Password", IsPassword=true };
            m_password.Margin = new Thickness(10, 0, 10, 0);

            m_loginButton = new Button() { Text = "Login", IsEnabled = true };
            m_signUp = new Button() { Text = "Sign Up", IsEnabled = true };
            m_loginButton.Clicked += OnLoginButtonClick;
            m_signUp.Clicked += SignUpButtonClick;
            Content = new StackLayout
            {
                VerticalOptions = LayoutOptions.CenterAndExpand,

                Children = { 
                    m_userName,m_password,m_loginButton,m_signUp
                }
            };
        }

        void OnLoginButtonClick(object sender, EventArgs e)
        {
            //string sendusername;
            //string sendpassword
            //Going to need to send the username and password to the database
            //First check if the username is valid so query database for that username
            //then see if the password with the salt and the hash is the correct password
            //If it is correct then take them to the next page

            //m_certiTracker.MainPage = new MasterPage();

        }
        void SignUpButtonClick(object sender, EventArgs e)
        {
            //Click sign up and 
        }
    }
}