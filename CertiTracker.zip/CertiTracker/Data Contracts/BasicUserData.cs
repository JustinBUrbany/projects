﻿/* Purpose:
 *      This file holds a data contract
 * Created:
 *      11/23/17 Wilks
 * Change log:
 *      
 */
using System.Runtime.Serialization;

namespace Mobile_Server_Application
{
    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    // You can add XSD files into the project. After building the project, you can directly use the data types defined there, with the namespace "Mobile_Server_Library.ContractType".
    [DataContract]
    public class BasicUserData
    {

        protected int _UserID = -1;
        protected string _FName;
        protected string _LName;
        protected string _Email;
        protected string _AreaOfInterest;
        protected string _Background;
        protected string _Location;

        public BasicUserData(int UserID, string FName, string LName, string Email, string AreaOfInterest, string Background, string Location)
        {
            _UserID = UserID;
            _FName = FName;
            _LName = LName;
            _Email = Email;
            _AreaOfInterest = AreaOfInterest;
            _Background = Background;
            _Location = Location;
        }

        [DataMember]
        public int UserID { get { return _UserID; } set { _UserID = value; } }

        [DataMember]
        public string FName { get { return _FName; } set { _FName = value; } }

        [DataMember]
        public string LName { get { return _LName; } set { _LName = value; } }

        [DataMember]
        public string Email { get { return _Email; } set { _Email = value; } }

        [DataMember]
        public string AreaOfInterest { get { return _AreaOfInterest; } set { _AreaOfInterest = value; } }

        [DataMember]
        public string Background { get { return _Background; } set { _Background = value; } }

        [DataMember]
        public string Location { get { return _Location; } set { _Location = value; } }

    }
}
