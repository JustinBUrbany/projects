﻿/* Purpose:
 *      This file holds a data contract
 * Created:
 *      11/23/17 Wilks
 * Change log:
 *      
 */
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Mobile_Server_Application
{
    [DataContract]
    public class FormObject
    {
        protected FormData _BaseFormData;
        protected List<FormCompetency> _FormCompetencies = new List<FormCompetency>();
        protected List<FormCharacteristic> _FormCharacteristics = new List<FormCharacteristic>();
        protected List<FormEvalField> _FormEvalFields = new List<FormEvalField>();

        [DataMember]
        public FormData BaseFormData { get { return _BaseFormData; } set { _BaseFormData = value; } }
        [DataMember]
        public List<FormCompetency> FormCompetencies { get { return _FormCompetencies; } set { _FormCompetencies = value; } }
        [DataMember]
        public List<FormCharacteristic> FormCharacteristics { get { return _FormCharacteristics; } set { _FormCharacteristics = value; } }
        [DataMember]
        public List<FormEvalField> FormEvalFields { get { return _FormEvalFields; } set { _FormEvalFields = value; } }
    }
}

