﻿/* Purpose:
 *      This file holds a data contract
 * Created:
 *      11/23/17 Wilks
 * Change log:
 *      
 */
using System.Runtime.Serialization;

namespace Mobile_Server_Application
{
    [DataContract]
    public class FormCharacteristic
    {
        protected ItemCategoryData _Activity;
        protected string _ActivityText;

        [DataMember]
        public ItemCategoryData Activity { get { return _Activity; } set { _Activity = value; } }
        [DataMember]
        public string ActivityText { get { return _ActivityText; } set { _ActivityText = value; } }
    }
}

