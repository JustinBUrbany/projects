﻿/* Purpose:
 *      This file holds a data contract
 * Created:
 *      11/23/17 Wilks
 * Change log:
 *      
 */
using System.Runtime.Serialization;

namespace Mobile_Server_Application
{
    [DataContract]
    public class FormEvalField
    {
        protected ItemCategoryData _EvalCategory;
        protected ItemCategoryData _Grade;

        [DataMember]
        public ItemCategoryData EvalCategory { get { return _EvalCategory; } set { _EvalCategory = value; } }
        [DataMember]
        public ItemCategoryData Grade { get { return _Grade; } set { _Grade = value; } }
    }
}

