﻿/* Purpose:
 *      This file holds a data contract
 * Created:
 *      11/23/17 Wilks
 * Change log:
 *      
 */
using System;
using System.Runtime.Serialization;

namespace Mobile_Server_Application
{
    [DataContract]
    public class FormCompetency
    {
        protected ItemCategoryData _CompetencyID;
        protected DateTime _EvaluationDate;
        protected ItemCategoryData _SelfEvalStanding;
        protected ItemCategoryData _Goal;
        protected ItemCategoryData _ValidationMethod;
        protected ItemCategoryData _Status;

        [DataMember]
        public ItemCategoryData CompetencyID { get { return _CompetencyID; } set { _CompetencyID = value; } }
        [DataMember]
        public DateTime EvaluationDate { get { return _EvaluationDate; } set { _EvaluationDate = value; } }
        [DataMember]
        public ItemCategoryData SelfEvalStanding { get { return _SelfEvalStanding; } set { _SelfEvalStanding = value; } }
        [DataMember]
        public ItemCategoryData Goal { get { return _Goal; } set { _Goal = value; } }
        [DataMember]
        public ItemCategoryData ValidationMethod { get { return _ValidationMethod; } set { _ValidationMethod = value; } }
        [DataMember]
        public ItemCategoryData Status { get { return _Status; } set { _Status = value; } }
    }
}

