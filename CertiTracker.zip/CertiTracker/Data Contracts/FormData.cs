﻿/* Purpose:
 *      This file holds a data contract
 * Created:
 *      11/23/17 Wilks
 * Change log:
 *      
 */
using System;
using System.Runtime.Serialization;

namespace Mobile_Server_Application
{
    [DataContract]
    public class FormData
    {
        protected int _FormID;
        protected Relationship _FormRelatioship;
        protected DateTime _StartDate;
        protected DateTime _EndDate;
        protected ItemCategoryData _FormGrade;
        protected string _Comments;
        protected bool? _ValidForm;

        [DataMember]
        public int FormID { get { return _FormID; } set { _FormID = value; } }
        [DataMember]
        public Relationship FormRelatioship { get { return _FormRelatioship; } set { _FormRelatioship = value; } }
        [DataMember]
        public DateTime StartDate { get { return _StartDate; } set { _StartDate = value; } }
        [DataMember]
        public DateTime EndDate { get { return _EndDate; } set { _EndDate = value; } }
        [DataMember]
        public ItemCategoryData FormGrade { get { return _FormGrade; } set { _FormGrade = value; } }
        [DataMember]
        public string Comments { get { return _Comments; } set { _Comments = value; } }
        [DataMember]
        public bool? ValidForm { get { return _ValidForm; } set { _ValidForm = value; } }
    }
}

