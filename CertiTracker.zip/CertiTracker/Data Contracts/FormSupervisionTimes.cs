﻿/* Purpose:
 *      This file holds a data contract
 * Created:
 *      11/23/17 Wilks
 * Change log:
 *      
 */
using System;
using System.Runtime.Serialization;

namespace Mobile_Server_Application
{
    [DataContract]
    public class FormSupervisionTimes
    {
        protected DateTime _SupervisionDate;
        protected TimeSpan _SupervisionDuration;

        [DataMember]
        public DateTime SupervisionDate { get { return _SupervisionDate; } set { _SupervisionDate = value; } }
        [DataMember]
        public TimeSpan SupervisionDuration { get { return _SupervisionDuration; } set { _SupervisionDuration = value; } }
    }
}

