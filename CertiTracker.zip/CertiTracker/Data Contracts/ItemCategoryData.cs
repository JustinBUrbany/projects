﻿/* Purpose:
 *      This file holds a data contract
 * Created:
 *      11/23/17 Wilks
 * Change log:
 *      
 */
using System.Runtime.Serialization;

namespace Mobile_Server_Application
{
    [DataContract]
    public class ItemCategoryData
    {
        protected int _CategoryItemID;
        protected short _CategoryType;
        protected string _ItemTitle;
        protected string _ItemBody;

        [DataMember]
        public int CategoryItemID { get { return _CategoryItemID; } set { _CategoryItemID = value; } }
        [DataMember]
        public short CategoryType { get { return _CategoryType; } set { _CategoryType = value; } }
        [DataMember]
        public string ItemTitle { get { return _ItemTitle; } set { _ItemTitle = value; } }
        [DataMember]
        public string ItemBody { get { return _ItemBody; } set { _ItemBody = value; } }
    }
}

