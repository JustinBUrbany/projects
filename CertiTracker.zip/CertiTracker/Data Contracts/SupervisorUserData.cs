﻿/* Purpose:
 *      This file holds a data contract
 * Created:
 *      11/23/17 Wilks
 * Change log:
 *      
 */
using System;
using System.Runtime.Serialization;

namespace Mobile_Server_Application
{
    [DataContract]
    public class SupervisorUserData : BasicUserData
    {
        protected int _SupervisorID;
        protected string _CertifcationNumber;
        protected DateTime _DateCertified;
        protected DateTime _DateCompletedSupervision;
        protected bool _DistanceSupervision;

        public SupervisorUserData(int UserID, string FName, string LName, string Email, string AreaOfInterest, string Background, string Location, 
            int SupervisorID, string CertifcationNumber, DateTime DateCertified, DateTime DateCompletedSupervision, bool DistanceSupervision) : 
            base(UserID, FName, LName, Email, AreaOfInterest, Background, Location)
        {
            _SupervisorID = SupervisorID;
            _CertifcationNumber = CertifcationNumber;
            _DateCertified = DateCertified;
            _DateCompletedSupervision = DateCompletedSupervision;
            _DistanceSupervision = DistanceSupervision;
        }

        [DataMember]
        public int SupervisorID { get { return _SupervisorID; } set { _SupervisorID = value; } }

        [DataMember]
        public string CertifcationNumber { get { return _CertifcationNumber; } set { _CertifcationNumber = value; } }

        [DataMember]
        public DateTime DateCertified { get { return _DateCertified; } set { _DateCertified = value; } }

        [DataMember]
        public DateTime DateCompletedSupervision { get { return _DateCompletedSupervision; } set { _DateCompletedSupervision = value; } }

        [DataMember]
        public bool DistanceSupervision { get { return _DistanceSupervision; } set { _DistanceSupervision = value; } }
    }
}
