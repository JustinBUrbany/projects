﻿/* Purpose:
 *      This file holds a data contract
 * Created:
 *      11/23/17 Wilks
 * Change log:
 *      11/27/17 Wilks
 *          added comment to match database
 */
 using System;
using System.Runtime.Serialization;

namespace Mobile_Server_Application
{
    [DataContract]
    public class Relationship
    {
        /*
         * Purpose - This class is meant to hold a relationship between supervisor and a supervisee.
         * Note that the participants are stored as id's rather than than userdata. 
         * This is intended to reduce redudency when data is used on the mobile component.
         * ie, mobile user is stored once.
        */
        protected int _RelationshipID;
        protected int _SupervisorID;
        protected int _SuperviseeID;
        protected DateTime _StartDate;
        protected DateTime _EndDate;
        protected string _Comments;

        public Relationship(int RelationshipID, int SupervisorID, int SuperviseeID, DateTime StartDate, DateTime EndDate, string Comments)
        {
            _RelationshipID = RelationshipID;
            _SupervisorID = SupervisorID;
            _SuperviseeID = SuperviseeID;
            _StartDate = StartDate;
            _EndDate = EndDate;
            _Comments = Comments;
        }

        [DataMember]
        public int RelationshipID { get { return _RelationshipID; } set { _RelationshipID = value; } }
        [DataMember]
        public int SupervisorID { get { return _SupervisorID; } set { _SupervisorID = value; } }
        [DataMember]
        public int SuperviseeID { get { return _SuperviseeID; } set { _SuperviseeID = value; } }
        [DataMember]
        public DateTime StartDate { get { return _StartDate; } set { _StartDate = value; } }
        [DataMember]
        public DateTime EndDate { get { return _EndDate; } set { _EndDate = value; } }
        [DataMember]
        public string Comments { get { return _Comments; } set { _Comments = value; } }
    }
}

