﻿/* Purpose:
 *      This file holds a data contract
 * Created:
 *      11/23/17 Wilks
 * Change log:
 *      
 */
using System.Runtime.Serialization;

namespace CertiTracker
{
    public class BasicUserData
    {
        protected int _UserID = -1;
        protected string _FName;
        protected string _LName;
        protected string _Email;
        protected string _AreaOfInterest;
        protected string _Background;
        protected string _Location;

        public BasicUserData(int UserID, string FName, string LName, string Email, string AreaOfInterest, string Background, string Location)
        {
            _UserID = UserID;
            _FName = FName;
            _LName = LName;
            _Email = Email;
            _AreaOfInterest = AreaOfInterest;
            _Background = Background;
            _Location = Location;
        }


        public int UserID { get { return _UserID; } set { _UserID = value; } }


        public string FName { get { return _FName; } set { _FName = value; } }


        public string LName { get { return _LName; } set { _LName = value; } }

        public string Email { get { return _Email; } set { _Email = value; } }


        public string AreaOfInterest { get { return _AreaOfInterest; } set { _AreaOfInterest = value; } }


        public string Background { get { return _Background; } set { _Background = value; } }


        public string Location { get { return _Location; } set { _Location = value; } }

    }
}
