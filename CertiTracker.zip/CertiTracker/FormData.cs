﻿/* Purpose:
 *      This file holds a data contract
 * Created:
 *      11/23/17 Wilks
 * Change log:
 *      
 */
using System;
using System.Runtime.Serialization;

namespace CertiTracker
{
    
    public class FormData
    {
        public FormData(int formID, int formRelationship, string startDate, string end, int formgrade, string comments, bool? validForm)
        {
            _FormID = formID;
            _FormRelationship = formRelationship;
            _StartDate = startDate;
            _EndDate = end;
            _FormGrade = formgrade;
            _Comments = comments;
            _ValidForm = validForm;
        }

        protected int _FormID;
        //protected Relationship _FormRelatioship;
        protected int _FormRelationship;
        protected string _StartDate;
        protected string _EndDate;
        //protected ItemCategoryData _FormGrade;
        protected int _FormGrade;
        protected string _Comments;
        protected bool? _ValidForm;


        public int FormID { get { return _FormID; } set { _FormID = value; } }

        public int FormRelationship { get { return _FormRelationship; } set { _FormRelationship = value; } }

        public string StartDate { get { return _StartDate; } set { _StartDate = value; } }

        public string EndDate { get { return _EndDate; } set { _EndDate = value; } }

        public int FormGrade { get { return _FormGrade; } set { _FormGrade = value; } }

        public string Comments { get { return _Comments; } set { _Comments = value; } }

        public bool? ValidForm { get { return _ValidForm; } set { _ValidForm = value; } }
    }
}

