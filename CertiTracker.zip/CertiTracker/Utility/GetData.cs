﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace CertiTracker.Utility
{
    public static class GetData
    {
        static string m_connection = "http://certitracker-env.us-west-2.elasticbeanstalk.com";


        public static T getData<T>(string urlVariables)
        {
            string result;

            try
            {
                HttpClient client = new HttpClient();
                client.DefaultRequestHeaders.Add("Accept", "application/json");

                Task<HttpResponseMessage> getDataFromHTTP = client.GetAsync(m_connection + urlVariables);
                getDataFromHTTP.Wait();
                HttpResponseMessage response = getDataFromHTTP.Result;

                result = response.Content.ReadAsStringAsync().Result;
			}
            catch (System.AggregateException e)
            {
                throw new CertiTrackerException(e.Message);
            }

            return JsonConvert.DeserializeObject<T>(result);
        }
    }
}
