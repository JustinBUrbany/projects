﻿using System;
namespace CertiTracker.Utility
{
    public static class StaticUser
    {
        public static int UserID;
        public static int SUserID;

        public static bool isSupervisor = false;
    }
}
