﻿using System;
namespace CertiTracker.Utility
{
    public class CertiTrackerException : Exception
    {
        string m_message;
        public CertiTrackerException(string message)
        {
            m_message = message;
        }

        public override string Message
        {
            get
            {
                return m_message;
            }
        }
    }
}
