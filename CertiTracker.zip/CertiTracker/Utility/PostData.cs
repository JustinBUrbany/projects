﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CertiTracker.Utility
{
    public static class PostData
    {
        static string m_connection = "http://certitracker-env.us-west-2.elasticbeanstalk.com/";



        public static Task<HttpResponseMessage> postData<T>(T data, string urlVariables)
        {
           

            string content = JsonConvert.SerializeObject(data);
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Add("Accept", "Application/json");


            var response = client.PostAsync(m_connection+urlVariables, new StringContent(content, Encoding.UTF8, "application/json"));
            response.Wait();

            return response;
        }

    }
}
