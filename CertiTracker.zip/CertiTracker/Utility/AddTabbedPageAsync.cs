﻿using System;
using CertiTracker.Pages;
using Xamarin.Forms;

namespace CertiTracker
{
    [Obsolete]
    public class AddTabbedPageAsync<T> : ContentPage where T : CertiTrackerTabbedPage
    {
        T page = null;

        public AddTabbedPageAsync(string id)
        {
            page = (T)Activator.CreateInstance(typeof(T), new object[] { id });

            Content = new ActivityIndicator() { IsRunning = true, Color = Color.FromRgb(0, 160, 255) };
        }

        public AddTabbedPageAsync(string id, string supervisoruserid, string supervisorid = "")
        {
            page = (T)Activator.CreateInstance(typeof(T), new object[] { id, supervisoruserid, supervisorid });

            Content = new ActivityIndicator() { IsRunning = true, Color = Color.FromRgb(0, 160, 255) };
        }


        public async void Push()
        {
            page.BuildPage();

            await Navigation.PushAsync(page);

            if (page.errorLabel != null)
            {
                foreach (var i in Navigation.NavigationStack)
                {
                    if (i == this)
                    {
                        Navigation.RemovePage(this);
                        break;
                    }

                }
            }
            else
            {
                Navigation.RemovePage(this);
            }

        }

        public async void GetData()
        {
            page.GetPageData();
            Action action = Push;
            Device.BeginInvokeOnMainThread(action);
        }
    }
}
