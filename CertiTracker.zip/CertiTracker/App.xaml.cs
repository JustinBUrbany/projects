﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Xamarin.Forms;

namespace CertiTracker
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
            //controller = new UIStackController(this);
            //UIStackController.Instance.PushMainPage(new MockLogin());

            //NavigationPage m = new NavigationPage(new MockLogin());

            MainPage = new NavigationPage(new MockLogin(this));
            //Login login = new Login(this);
            //MockLogin login1 = new MockLogin();
            ////MainPage = login;
            //MainPage = login1;
      




            //MainPage = new MainPage();


        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
