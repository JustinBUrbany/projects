﻿/************************************************************ 
* Author: Carl Lowther 
*  
* Current use of this page is to be determined right now it 
* is going to to be used as refrence page maybe removed in the future 
*  
*  
*  
*  
*  
*  
*  
*  
*************************************************************/
//using System; 
//using System.Net.Http; 
//using System.Threading.Tasks; 
//using System.Collections.Generic; 
//using Xamarin.Forms; 
//using Newtonsoft.Json; 

//namespace CertiTracker 
//{ 
//    public class Supervisors : ContentPage 
//    { 
//        public Supervisors() 
//        { 
//            StackLayout temp = new StackLayout(); 

//            temp.Margin = new Thickness(10, 10, 10, 0); 


//            for (int i = 1; i < 6; i++) 
//            { 
//                //BasicUserData user = JsonConvert.DeserializeObject<BasicUserData>(GetUser(i)); 

//                temp.Children.Add(new Label { Text = "UserID: " + user.UserID.ToString() }); 
//                temp.Children.Add(new Label { Text = "First Name: " + user.FName }); 
//                temp.Children.Add(new Label { Text = "Last Name: " + user.LName }); 
//                temp.Children.Add(new Label { Text = "Email: " + user.Email }); 
//                temp.Children.Add(new Label { Text = "Area of Interest: " + user.AreaOfInterest }); 
//                temp.Children.Add(new Label { Text = "Background: " + user.Background }); 
//                temp.Children.Add(new Label { Text = "Location: " + user.Location }); 
//                temp.Children.Add(new Label()); 
//                temp.Children.Add(new Label()); 
//            } 



//            Content = new ScrollView { Content = temp }; 
//        } 

//        public string GetUser(int id) 
//        { 
//            HttpClient client = new HttpClient(); 
//            client.DefaultRequestHeaders.Add("Accept", "application/json"); 

//            Task<HttpResponseMessage> getUser = client.GetAsync("http://localhost:8080/user/" + id.ToString()); 
//            getUser.Wait(); 
//            HttpResponseMessage response = getUser.Result; 

//            return response.Content.ReadAsStringAsync().Result; 

//        } 
//    } 
//} 