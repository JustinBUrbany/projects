﻿/************************************************************ 
* Author: Justin Urbany 
* Last edited: January 18, 2017 
*  
* This class is designed to be a profile description page will 
* contain all the users basic information and will be set up
* so the user can change their information upon request
*  
*  
*  
*  
*  
*  
*************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CertiTracker.Pages;
using CertiTracker.Utility;
using DataContainers.Users;
using Xamarin.Forms;

namespace CertiTracker
{
    public class ManageProfile : CertiTrackerContentPage
    {
        Entry m_firstname = new Entry();
        Entry m_lastname = new Entry();
        Entry m_email = new Entry();

        Entry m_location = new Entry();
        Entry m_areasofintrest = new Entry();
        Entry m_moreuserinfo = new Entry();

        Button m_Update = new Button();

		ExpandedUser user = null;
  
        public ManageProfile()
        {
            this.Padding = new Thickness(17.5, 15, 17.5, 0);
            Content = new ActivityIndicator() { IsRunning = true, Color = Color.FromRgb(0, 160, 255) };
            Task.Run(() => GetPageData()); 
        }


        override public void BuildPage()
        {
			StackLayout pagelayout = new StackLayout();
			Grid g_profile = null;

            if (errorLabel == null)
            {
                this.Title = "Profile";
                m_Update.Text = "Update";
                m_Update.TextColor = Color.White;
                m_Update.BackgroundColor = Color.FromRgb(0, 160, 255);
                m_Update.Clicked += UpdateClicked;

                m_Update.IsEnabled = false;
                Label firstname = new Label();
                firstname.Text = "First name:";

                Label lastname = new Label();
                lastname.Text = "Last name:";

                Label location = new Label();
                location.Text = "Location:";

                Label email = new Label();
                email.Text = "Email:";


                Label areasofintrest = new Label();
                areasofintrest.Text = "Intrests:";

                Label backgroundinfo = new Label();
                backgroundinfo.Text = "Background:";


                m_firstname.Text = user.FName;
                m_firstname.TextChanged += MadeChange;

                m_lastname.Text = user.LName;
                m_lastname.TextChanged += MadeChange;

                m_email.Text = user.Email;
                m_email.TextChanged += MadeChange;

                m_location.Text = user.Location;
                m_location.TextChanged += MadeChange;

                m_areasofintrest.Text = user.AreaOfInterest;
                m_areasofintrest.TextChanged += MadeChange;

                m_moreuserinfo.Text = user.Background;
                m_moreuserinfo.TextChanged += MadeChange;

                g_profile = new Grid();
                var children = g_profile.Children;
                children.Add(firstname, 0, 1);
                children.Add(m_firstname, 1, 1);
                children.Add(lastname, 0, 2);
                children.Add(m_lastname, 1, 2);
                children.Add(email, 0, 3);
                children.Add(m_email, 1, 3);
                children.Add(location, 0, 4);
                children.Add(m_location, 1, 4);
                children.Add(areasofintrest, 0, 5);
                children.Add(m_areasofintrest, 1, 5);
                children.Add(backgroundinfo, 0, 6);
                children.Add(m_moreuserinfo, 1, 6);
                children.Add(m_Update, 1, 7);

                pagelayout.HorizontalOptions = LayoutOptions.CenterAndExpand;
                pagelayout.Children.Add(g_profile);
            }
            else
            {
                pagelayout.Children.Add(errorLabel);
            }

            ScrollView pageview = new ScrollView
            {
                Content = pagelayout
            };

            Content = pageview;



        }

        public override void GetPageData()
        {
            try
            {
                user = GetData.getData<ExpandedUser>("/getuser/" + StaticUser.UserID.ToString());
            }
            catch (CertiTrackerException e)
            {
                errorLabel = new Label() { Text = e.Message };
            }

            Action action = BuildPage;
            Device.BeginInvokeOnMainThread(action);
        }

        void MadeChange(object sender, EventArgs e)
        {
            m_Update.IsEnabled = true;
        }

        void UpdateClicked(object sender, EventArgs e)
        {
            m_Update.IsEnabled = false;
        }


    }
}