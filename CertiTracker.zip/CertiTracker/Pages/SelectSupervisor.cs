﻿/**********************************************************************************
 * The purpose of this page is to select which supervisor is going to be associated with
 * the new form a supervisee will be creating.
 * 
 * Author: Justin Urbany
 * Date: 2/27/2018
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************************/
using CertiTracker.Utility;
using DataContainers.Users;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Xamarin.Forms;
using CertiTracker.Pages.Forms;
using System.Threading.Tasks;

namespace CertiTracker.Pages
{
    public class SelectSupervisor : ContentPage
    {
        Picker m_supervisors = new Picker();
        Button m_newform = new Button();
        List<SupervisorUser> m_listsupervisors;
        string m_superviseeid;

        private Label errorLabel;

        public SelectSupervisor(string superviseeid)
        {
            this.Title = "Select a Supervisor";
            m_superviseeid = superviseeid;
            m_newform.Text = "Start New Form";
            m_newform.BackgroundColor = Color.FromRgb(0, 160, 255);
            m_newform.TextColor = Color.White;
            m_newform.Clicked += NewFormClicked;
            m_supervisors.Title = "Select a Supervisor";

            GetPageData();
            //TODO make a build page function and make aysnc
            if (errorLabel != null)
            {
                StackLayout pagelayout = new StackLayout();
                pagelayout.Children.Add(errorLabel);
                ScrollView pagescroll = new ScrollView
                {
                    Content = pagelayout
                };
                Content = pagescroll;
            }
            else
            {
                MakePicker();

                m_supervisors.SelectedIndex = 0;
                Content = new StackLayout
                {
                    HorizontalOptions = LayoutOptions.CenterAndExpand,
                    VerticalOptions = LayoutOptions.CenterAndExpand,
                    Children = 
                    {
                        m_supervisors,
                        m_newform
                    }
                };
            }
        }

        void MakePicker()
        {
            foreach (var supervisors in m_listsupervisors)
            {
                string temp = supervisors.FName + " " + supervisors.LName;
                m_supervisors.Items.Add(temp);
            }

        }

        async void NewFormClicked(object sender, EventArgs e)
        {
            //AddTabbedPageAsync<BlankForm> n = new AddTabbedPageAsync<BlankForm>(m_superviseeid,m_listsupervisors[m_supervisors.SelectedIndex].UID.ToString(), m_listsupervisors[m_supervisors.SelectedIndex].SID.ToString());

            //await Navigation.PushAsync(n);

            //await Task.Run(() =>
            //{
            //    n.GetData();
            //});

            //Navigation.RemovePage(this);
            await Navigation.PushAsync(new BlankForm(m_superviseeid, 
                                                     m_listsupervisors[m_supervisors.SelectedIndex].UID.ToString(), 
                                                     m_listsupervisors[m_supervisors.SelectedIndex].SID.ToString()));
        }

        public void GetPageData()
        {
            try
            {
                m_listsupervisors = GetData.getData<List<SupervisorUser>>("/GetRelationship/User/Supervisors/" + m_superviseeid);
            }
            catch (CertiTrackerException e)
            {
                errorLabel = new Label() { Text = e.Message };
            }
        }
    }
}