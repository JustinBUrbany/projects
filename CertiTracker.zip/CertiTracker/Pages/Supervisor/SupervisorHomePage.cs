﻿/************************************************************ 
* Author: Justin Urbany 
* Last edited: January 18, 2017 
*  
* This class is designed to be the next page after a user 
* Logs in as a supervisee this will be the home page and contain 
* all links for features users can use as a supervisee  
*  
*  
*  
*  
*  
*  
*************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace CertiTracker
{
    public class SupervisorHomePage : ContentPage
    {

        Button m_supervisees = new Button();
        Button m_requests = new Button();
        Button m_manageProfile = new Button();
        Button m_currentForms = new Button();

        public SupervisorHomePage()
        {
            this.Padding = new Thickness(17.5, 15, 17.5, 0);
            this.Title = "Home";
            m_supervisees.Text = "Supervisees";
            m_supervisees.TextColor = Color.White;
            m_supervisees.Clicked += OnSuperviseesClicked;
            m_supervisees.BackgroundColor = Color.FromRgb(0, 160, 255);
            m_requests.Text = "Requests";
            m_requests.TextColor = Color.White;
            m_requests.BackgroundColor = Color.FromRgb(0, 160, 255);
            m_requests.Clicked += OnRequestsClicked;
            m_manageProfile.Text = "ManageProfile";
            m_manageProfile.TextColor = Color.White;
            m_manageProfile.BackgroundColor = Color.FromRgb(0, 160, 255);
            m_manageProfile.Clicked += OnManageProfileClicked;
            m_currentForms.Text = "CurrentForms";
            m_currentForms.TextColor = Color.White;
            m_currentForms.BackgroundColor = Color.FromRgb(0, 160, 255);
            m_currentForms.Clicked += OnCurrentFromsClicked;


            Content = new StackLayout
            {
                //BackgroundColor = Color.FromRgb(0, 160, 255),
                Children = {
                    m_supervisees,m_requests,m_manageProfile,m_currentForms
                }
            };
        }
        async void OnSuperviseesClicked(object sender, EventArgs e)
        {
            //AddContentPageAsync<SuperviseeList> n = new AddContentPageAsync<SuperviseeList>();
            //await Navigation.PushAsync(n);

            //await Task.Run(() =>
            //{
            //    n.GetData();
            //});

            await Navigation.PushAsync(new SuperviseeList());
        }

        void OnRequestsClicked(object sender, EventArgs e)
        {
            //m_certiTracker.MainPage= new SuperviseeHomePage();
        }
        async void OnManageProfileClicked(object sender, EventArgs e)
        {

            //AddContentPageAsync<ManageProfile> n = new AddContentPageAsync<ManageProfile>((sender as Button).StyleId);

            //await Navigation.PushAsync(n);

            //await Task.Run(() =>
            //{
            //    n.GetData();
            //});

            await Navigation.PushAsync(new ManageProfile());

            //m_certiTracker.MainPage= new SuperviseeHomePage();
        }
        void OnCurrentFromsClicked(object sender, EventArgs e)
        {
            //m_certiTracker.MainPage= new SuperviseeHomePage();
        }
    }
}