﻿using CertiTracker.Utility;
using DataContainers.Users;
using System;
using System.Collections.Generic;
using Xamarin.Forms;
using CertiTracker.Pages;
using System.Threading.Tasks;

namespace CertiTracker
{
    public class SuperviseeList : CertiTrackerContentPage
    {
        Button search = new Button();

        List<BaseUser> m_superviseelist = null;

        public SuperviseeList()
        {
            this.Padding = new Thickness(17.5, 15, 17.5, 0);
            this.Title = "Your Supervisees";

            Content = new ActivityIndicator() { IsRunning = true, Color = Color.FromRgb(0, 160, 255) };
            Task.Run(() => GetPageData()); 
        }

        override public void BuildPage()
        {
			StackLayout pagelayout = new StackLayout();

            if (errorLabel == null)
            {
                List<Button> buttons = new List<Button>();

                search.Text = "Find Supervisee";
                search.BackgroundColor = Color.FromRgb(0, 160, 255);
                search.Clicked += OnSearchClick;

                foreach (BaseUser b in m_superviseelist)
                {
                    buttons.Add(new Button()
                    {
                        Text = b.FName.ToString() + "  " + b.LName.ToString(),
                        StyleId = b.UID.ToString(),
                        BackgroundColor = Color.FromRgb(0, 160, 255),
                        TextColor = Color.White
                    });

                    buttons[buttons.Count - 1].Clicked += SHSuperviseeClick;
                    pagelayout.Children.Add(buttons[buttons.Count - 1]);
                }
            }
            else
            {
                pagelayout.Children.Add(errorLabel);
            }

            ScrollView pagescroll = new ScrollView
            {
                Content = pagelayout
            };
            Content = pagescroll;
        }

        public override void GetPageData()
        {
            try
            {
                m_superviseelist = GetData.getData<List<BaseUser>>("/GetRelationship/Supervisors/Supervisees/" + StaticUser.SUserID.ToString());
            }
            catch (CertiTrackerException e)
            {
                errorLabel = new Label() { Text = e.Message };
            }

            Action action = BuildPage;
            Device.BeginInvokeOnMainThread(action);
        }


        async void OnSearchClick(object sender, EventArgs e)
        {
            //await somefunc();
        }

        async void SHSuperviseeClick(object sender, EventArgs e)
        {
            //AddContentPageAsync<FormsPage> n = new AddContentPageAsync<FormsPage>((sender as Button).StyleId);
			
            //await Navigation.PushAsync(n);

            //await Task.Run(() => 
            //{
            //    n.GetData();
            //});


            await Navigation.PushAsync(new FormsPage((sender as Button).StyleId));
        }
    }
}
