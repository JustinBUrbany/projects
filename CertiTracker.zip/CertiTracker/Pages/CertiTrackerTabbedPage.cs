﻿using System;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace CertiTracker.Pages
{
    abstract public class CertiTrackerTabbedPage : TabbedPage
    {
        public Label errorLabel = null;

        abstract public void BuildPage();
        public virtual void GetPageData()
        { }
    }
}
