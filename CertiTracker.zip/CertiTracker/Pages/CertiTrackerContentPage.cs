﻿using System;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace CertiTracker.Pages
{
    abstract public class CertiTrackerContentPage : ContentPage
    {
        public Label errorLabel = null;

        abstract public void BuildPage();
        public virtual void GetPageData()
        { }
    }
}
