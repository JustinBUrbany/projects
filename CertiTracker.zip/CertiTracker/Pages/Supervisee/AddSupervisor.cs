﻿using CertiTracker.Utility;
using DataContainers.Users;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Xamarin.Forms;

namespace CertiTracker.Pages.Supervisee
{
    public class AddSupervisor : ContentPage
    {
        Entry m_firstname = new Entry() { Placeholder = "Supervisor First Name" };
        Entry m_lastname = new Entry() { Placeholder = "Supervisor Last Name" };
        Button Search = new Button() { Text = "Search", BackgroundColor = Color.FromRgb(0, 160, 255), TextColor = Color.White};
        List<BaseUser> Supervisors = new List<BaseUser>();
        List<Button> SupervisorButtons = new List<Button>();
        public AddSupervisor()
        {
            Search.Clicked += OnSearchClicked;
            this.Title = "Add Supervisor";
            Content = new StackLayout
            {
                HorizontalOptions = LayoutOptions.CenterAndExpand,
                
                Children ={
                    m_firstname,
                    m_lastname,
                    Search,
                }
                
            };
        }

        async public void OnSearchClicked(object sender, EventArgs e)
        {
            try
            {
                Supervisors = GetData.getData<List<BaseUser>>("Some url/" + m_firstname.Text + "/" + m_lastname.Text); //This needs to be the call to the server
                foreach(BaseUser s in Supervisors)
                {
                    SupervisorButtons.Add(new Button()
                    {
                        Text = s.FName + " " + s.LName,
                        TextColor = Color.White,
                        BackgroundColor = Color.FromRgb(0, 160, 255),
                        StyleId = s.UID.ToString()

                    }); //End of the button
                    SupervisorButtons[SupervisorButtons.Count - 1].Clicked += SupervisorClicked; //Click so supervisee can look at the supervisor and then Add them if they want
                    
                }
            }
            catch(CertiTrackerException)
            {
                await DisplayAlert("Error", "Error please try again.", "OK");
            }
        }
        async public void SupervisorClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new UserPage((sender as Button).StyleId, true));
        }
    }
}