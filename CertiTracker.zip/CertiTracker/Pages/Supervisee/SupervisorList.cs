﻿using CertiTracker.Utility;
using DataContainers.Users;
using System;
using System.Collections.Generic;
using Xamarin.Forms;
using CertiTracker.Pages;
using System.Threading.Tasks;
using CertiTracker.Pages.Supervisee;

namespace CertiTracker
{
    public class SupervisorList : CertiTrackerContentPage
    {
        Button AddSupervisor = new Button();

        List<BaseUser> m_supervisorlist = null;

        public SupervisorList()
        {
            this.Padding = new Thickness(17.5, 15, 17.5, 0);
            this.Title = "Your Supervisors";

            Content = new ActivityIndicator() { IsRunning = true, Color = Color.FromRgb(0, 160, 255) };
            Task.Run(() => GetPageData());
        }

        override public void BuildPage()
        {
            StackLayout pagelayout = new StackLayout();

            if (errorLabel == null)
            {
                List<Button> buttons = new List<Button>();
                Label RequestedSupervisors = new Label() { Text = "Currently Requested Supervisors" };
                AddSupervisor.Text = "Add Supervisor";
                AddSupervisor.BackgroundColor = Color.FromRgb(0, 160, 255);
                AddSupervisor.TextColor = Color.White;
                AddSupervisor.Clicked += OnSearchClick;

                foreach (BaseUser b in m_supervisorlist)
                {
                    buttons.Add(new Button()
                    {
                        Text = b.FName.ToString() + "  " + b.LName.ToString(),
                        StyleId = b.UID.ToString(),
                        BackgroundColor = Color.FromRgb(0, 160, 255),
                        TextColor = Color.White
                    });

                    buttons[buttons.Count - 1].Clicked += SHSupervisorClick;
                    pagelayout.Children.Add(buttons[buttons.Count - 1]);
                }
                pagelayout.Children.Add(AddSupervisor);
                pagelayout.Children.Add(RequestedSupervisors);
                /* Get the Users that you Requested could be base user or Expand User Make some Labels or Button and List those Users here Make the Call for Requested Supervisors in Get Data */
            }
            else
            {
                pagelayout.Children.Add(errorLabel);
            }

            ScrollView pagescroll = new ScrollView
            {
                Content = pagelayout
            };
            Content = pagescroll;
        }

        public override void GetPageData()
        {
            try
            {
                m_supervisorlist = GetData.getData<List<BaseUser>>("/GetRelationship/User/Supervisors/" + StaticUser.UserID.ToString());
            }
            catch (CertiTrackerException e)
            {
                errorLabel = new Label() { Text = e.Message };
            }

            Action action = BuildPage;
            Device.BeginInvokeOnMainThread(action);
        }

        async void OnSearchClick(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new AddSupervisor());
        }

        async void SHSupervisorClick(object sender, EventArgs e)
        {
            //AddContentPageAsync<UserPage> n = new AddContentPageAsync<UserPage>((sender as Button).StyleId);

            //await Navigation.PushAsync(n);

            //await Task.Run(() =>
            //{
            //    n.GetData();
            //});


            await Navigation.PushAsync(new UserPage((sender as Button).StyleId));
        }
    }
}