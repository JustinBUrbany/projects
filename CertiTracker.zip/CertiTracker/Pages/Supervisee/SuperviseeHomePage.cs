﻿/************************************************************
* Author: Justin Urbany
* Last edited: January 18, 2017
* 
* This class is designed to be the next page after a user
* Logs in as a supervisee this will be the home page and contain
* all links for features users can use as a supervisee 
* 
* 
* 
* 
* 
* 
*************************************************************/
using CertiTracker.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Xamarin.Forms;
using System.Threading.Tasks;
using CertiTracker.Pages;

namespace CertiTracker
{
    public class SuperviseeHomePage : ContentPage
    {
        Button m_forms = new Button();
        Button m_supervisors = new Button();
        Button m_manageProfile = new Button();
        Button m_currentForm = new Button();

        public SuperviseeHomePage()
        {
            this.Padding = new Thickness(17.5, 15, 17.5, 0);
            this.Title = "Home";
            m_forms.Text = "Forms";
            m_forms.WidthRequest = 74;
            m_forms.BackgroundColor = Color.FromRgb(0, 160, 255);
            m_forms.TextColor = Color.White;
            m_forms.Clicked += OnFormsClicked;

            m_supervisors.Text = "Supervisors";
            m_supervisors.BackgroundColor = Color.FromRgb(0, 160, 255);
            m_supervisors.TextColor = Color.White;
            m_supervisors.Clicked += OnSupervisorsClicked;

            m_manageProfile.Text = "ManageProfile";
            m_manageProfile.BackgroundColor = Color.FromRgb(0, 160, 255);
            m_manageProfile.TextColor = Color.White;
            m_manageProfile.Clicked += OnManageProfileClicked;

            m_currentForm.Text = "CurrentForm";
            m_currentForm.BackgroundColor = Color.FromRgb(0, 160, 255);
            m_currentForm.TextColor = Color.White;
            m_currentForm.Clicked += OnCurrentFromClicked;



            Content = new StackLayout
            {
                BackgroundColor = Color.White,
                Children = {
                    m_forms,m_supervisors,m_manageProfile,m_currentForm
                }
            };
        }

        async void OnFormsClicked(object sender, EventArgs e)
        {
            //AddContentPageAsync<FormsPage> n = new AddContentPageAsync<FormsPage>(StaticUser.UserID.ToString());

            //await Navigation.PushAsync(n);

            //await Task.Run(() =>
            //{
            //    n.GetData();
            //});


            await Navigation.PushAsync(new FormsPage(StaticUser.UserID.ToString()));
        }

        async void OnSupervisorsClicked(object sender, EventArgs e)
        {
            //AddContentPageAsync<SupervisorList> n = new AddContentPageAsync<SupervisorList>();

            //await Navigation.PushAsync(n);

            //await Task.Run(() =>
            //{
            //    n.GetData();
            //});

            await Navigation.PushAsync(new SupervisorList());
        }
        async void OnManageProfileClicked(object sender, EventArgs e)
        {
            //AddContentPageAsync<ManageProfile> n = new AddContentPageAsync<ManageProfile>();

            //await Navigation.PushAsync(n);

            //await Task.Run(() =>
            //{
            //    n.GetData();
            //});

            await Navigation.PushAsync(new ManageProfile());
        }

        async void OnCurrentFromClicked(object sender, EventArgs e)
        {
            //await Navigation.PushAsync(new Form("Justin", "Carl", DateTime.Today, 30.00f, DateTime.Today, DateTime.Now));
        }
    }
}