﻿using System;
using System.Threading.Tasks;
using CertiTracker.Utility;
using DataContainers.Users;
using Xamarin.Forms;
using DataContainers.Relationships;

namespace CertiTracker.Pages
{
    public class UserPage : CertiTrackerContentPage
    {
        Label m_firstname = new Label();
        Label m_lastname = new Label();
        Label m_email = new Label();

        Label m_location = new Label();
        Label m_areasofintrest = new Label();
        Label m_moreuserinfo = new Label();

        DatePicker StartDate = new DatePicker();
        DatePicker EndDate = new DatePicker();

        string m_userid = null;

        ExpandedUser m_user = null;

        bool m_IsSearch = false;

        public UserPage(string userid, bool Search=false)
        {
            m_userid = userid;
            if(Search == true)
            {
                m_IsSearch = true;
            }

            Content = new ActivityIndicator() { IsRunning = true, Color = Color.FromRgb(0, 160, 255) };
            Task.Run(() => GetPageData()); 

        }

        override public void BuildPage()
        {
            StackLayout pagelayout = new StackLayout();

            if (errorLabel == null)
            {
                this.Title = m_user.FName[0] + ". " + m_user.LName;
                Label firstname = new Label();
                firstname.Text = "First name:";
                firstname.HorizontalOptions = LayoutOptions.Center;
                Label lastname = new Label();
                lastname.Text = "Last name:";
                lastname.HorizontalOptions = LayoutOptions.Center;
                Label location = new Label();
                location.Text = "Location:";
                location.HorizontalOptions = LayoutOptions.Center;
                Label email = new Label();
                email.Text = "Email:";
                email.HorizontalOptions = LayoutOptions.Center;

                Label areasofintrest = new Label();
                areasofintrest.Text = "Intrests:";
                areasofintrest.HorizontalOptions = LayoutOptions.Center;
                Label backgroundinfo = new Label();
                backgroundinfo.Text = "Background:";
                backgroundinfo.HorizontalOptions = LayoutOptions.Center;

                m_firstname.Text = m_user.FName;
                m_lastname.Text = m_user.LName;
                m_email.Text = m_user.Email;
                m_location.Text = m_user.Location;
                m_areasofintrest.Text = m_user.AreaOfInterest;
                m_moreuserinfo.Text = m_user.Background;


                Grid g_profile = new Grid();
                g_profile.Children.Add(firstname, 0, 1);
                g_profile.Children.Add(m_firstname, 1, 1);
                g_profile.Children.Add(lastname, 0, 2);
                g_profile.Children.Add(m_lastname, 1, 2);
                g_profile.Children.Add(email, 0, 3);
                g_profile.Children.Add(m_email, 1, 3);
                g_profile.Children.Add(location, 0, 4);
                g_profile.Children.Add(m_location, 1, 4);
                g_profile.Children.Add(areasofintrest, 0, 5);
                g_profile.Children.Add(m_areasofintrest, 1, 5);
                g_profile.Children.Add(backgroundinfo, 0, 6);
                g_profile.Children.Add(m_moreuserinfo, 1, 6);


                if (m_IsSearch == true)
                {
                    Button SendRequest = new Button() { Text = "Request to Supervise", BackgroundColor = Color.FromRgb(0, 160, 255), TextColor = Color.White };
                    StartDate = new DatePicker();
                    EndDate = new DatePicker();
                    SendRequest.Clicked += RequestToSupervise;
                    g_profile.Children.Add(SendRequest, 1, 7);
                    g_profile.Children.Add(StartDate, 0, 8);
                    g_profile.Children.Add(EndDate, 0, 9);
                }
                pagelayout.HorizontalOptions = LayoutOptions.CenterAndExpand;
                pagelayout.Children.Add(g_profile);
            }
            else
            {
                pagelayout.Children.Add(errorLabel);
            }

            ScrollView pageview = new ScrollView
            {
                Content = pagelayout
            };

            Content = pageview;
        }

        private void RequestToSupervise(object sender, EventArgs e)
        {
            ExpandedRelationship relationShip = new ExpandedRelationship();
            relationShip.SuperviseeID = StaticUser.UserID;
            relationShip.SupervisorID = int.Parse(m_userid);
            relationShip.StartDate = StartDate.Date;
            relationShip.EndDate = EndDate.Date;
            PostData.postData<BaseRelationship>(relationShip, "/Relationship/Create/");
        }

        public override void GetPageData()
        {
            try
            {
                m_user = GetData.getData<ExpandedUser>("/getuser/" + m_userid);
            }
            catch (CertiTrackerException e)
            {
                errorLabel = new Label() { Text = e.Message };
            }

            Action action = BuildPage;
            Device.BeginInvokeOnMainThread(action);
        }
    }
}
