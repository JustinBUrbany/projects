﻿/************************************************************ 
* Author: Justin Urbany 
* last edited: January 18, 2018 
*  
* This class is designed to be a mock login so that no verification 
* is needed to login and both view of supervisee and supervisor 
* can be tested during production. In the future this page could 
* be used for an individual who is both a supervisor and was 
* a supervisee to select which profile they want to login too. 
*  
*  
*  
*  
*  
*************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CertiTracker.Utility;
using Xamarin.Forms;
using CertiTracker.Pages;

namespace CertiTracker
{
    public class MockLogin : ContentPage
    {
        Label m_header = new Label();

        Button m_setuser = new Button();
        Entry m_userid = new Entry() { Placeholder = "UserID" };

        Button m_setSuser = new Button();
        Entry m_Suserid = new Entry() { Placeholder = "SupevisorID" };

        Button m_supervisee = new Button();
        Button m_supervisor = new Button();
        Button m_signUp = new Button();
        Button m_forgotPassword = new Button();
        App m_certiTracker;

        public MockLogin(App app)
        {
            m_certiTracker = app;
            this.Padding = new Thickness(17.5, 0, 17.5, 0);
            this.Title = "Welcome";
            m_header.Text = "Login As:";
            m_header.FontSize = 40;
            m_header.HorizontalOptions = LayoutOptions.Center;

            m_setuser.Text = "Login with UserID";
            m_setuser.TextColor = Color.White;
            m_setuser.Clicked += OnUserClicked;
            m_setuser.BackgroundColor = Color.FromRgb(0, 160, 255);

            m_setSuser.Text = "Login with UserID";
            m_setSuser.TextColor = Color.White;
            m_setSuser.Clicked += OnSUserClicked;
            m_setSuser.BackgroundColor = Color.FromRgb(0, 160, 255);

            StaticUser.UserID = 133;

            m_supervisee.Text = "Supervisee";
            m_supervisee.TextColor = Color.White;
            m_supervisee.Clicked += OnSuperviseeClicked;
            m_supervisee.BackgroundColor = Color.FromRgb(0, 160, 255);

            m_supervisor.Text = "Supervisor";
            m_supervisor.TextColor = Color.White;
            m_supervisor.Clicked += OnSupervisorClicked;
            m_supervisor.BackgroundColor = Color.FromRgb(0, 160, 255);


            m_signUp.Text = "Sign Up?";
            m_signUp.FontSize = 14;
            m_signUp.FontAttributes = FontAttributes.Italic;
            m_signUp.BackgroundColor = Color.White;
            m_signUp.TextColor = Color.FromRgb(0, 122, 255);
            m_signUp.Clicked += OnSignUpClicked;

            m_forgotPassword.Text = "Forgot Password?";
            m_forgotPassword.FontSize = 14;
            m_forgotPassword.FontAttributes = FontAttributes.Italic;
            m_forgotPassword.BackgroundColor = Color.White;
            m_forgotPassword.TextColor = Color.FromRgb(0, 122, 255);
            m_forgotPassword.Clicked += M_forgotPassword_Clicked;


            Content = new StackLayout
            {
                VerticalOptions = LayoutOptions.CenterAndExpand,

                Children = {
                    m_header,m_supervisee,m_supervisor,m_userid, m_setuser, m_signUp, m_forgotPassword
                }
            };

        }

        private void OnUserClicked(object sender, EventArgs e)
        {
            if (m_userid.Text != null && m_userid.Text != "")
                StaticUser.UserID = int.Parse(m_userid.Text.ToString());
        }

        private void OnSUserClicked(object sender, EventArgs e)
        {
            if(m_Suserid.Text != null && m_Suserid.Text != "")
                StaticUser.UserID = int.Parse(m_Suserid.Text.ToString());
        }

        async public void M_forgotPassword_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new ForgotPassword());
        }

        async void OnSuperviseeClicked(object sender, EventArgs e)
        {
            StaticUser.isSupervisor = false;
            StaticUser.UserID = 133;

            await Navigation.PushAsync(new SuperviseeHomePage());
        }

        async void OnSupervisorClicked(object sender, EventArgs e)
        {
            StaticUser.UserID = 134;
            StaticUser.SUserID = 25;//supervisorID
            StaticUser.isSupervisor = true;

            await Navigation.PushAsync(new SupervisorHomePage());
        }

        async void OnSignUpClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new SignUpPage());//m_certiTracker));
        }
        //void SignUp(object sender, EventArgs e)
        //{
        //    m_certiTracker.MainPage = new SignUpPage(m_certiTracker);
        //}



    }
}