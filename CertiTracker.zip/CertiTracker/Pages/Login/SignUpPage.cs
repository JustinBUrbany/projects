﻿/************************************************************ 
* Author: Justin Urbany 
* Created: February 2, 2018 
*  
* This class is going to implemet a Sign Up page for users
* to register with out application and create a profile
*  
*************************************************************/
using CertiTracker.Utility;
using DataContainers.Users;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using Xamarin.Forms;
using System.Threading.Tasks;

namespace CertiTracker.Pages
{
    public class SignUpPage : ContentPage
    {
        Entry m_fName = new Entry();
        Entry m_lName = new Entry();
        Entry m_password = new Entry();
        Entry m_verifyPw = new Entry();
        Entry m_email = new Entry();

        Entry m_background = new Entry();
        Entry m_areasOfIntrest = new Entry();
        Entry m_location = new Entry();

        Entry m_certificationNumber = new Entry();
        DatePicker m_certificationDate = new DatePicker();
        DatePicker m_supervisionCompleted = new DatePicker();
        Picker m_distance = new Picker();
        bool? m_distanceSupervision;

        Button m_signUp = new Button();
        Picker m_picker = new Picker();

        DateTime m_dateSupervisonCompleted = new DateTime();
        DateTime m_dateCertified = new DateTime();


        public SignUpPage()//App app)
        {
            this.Title = "Sign Up";

            m_signUp.Text = "Confirm";
            m_signUp.TextColor = Color.White;
            m_signUp.BackgroundColor = Color.FromRgb(0, 160, 255);
            m_signUp.Clicked += MakeAccount;

            m_fName.Placeholder = "First name";
            m_fName.PlaceholderColor = Color.LightGray;
            m_fName.Keyboard = Keyboard.Default;
            m_lName.Placeholder = "Last name";
            m_lName.PlaceholderColor = Color.LightGray;



            m_email.Placeholder = "email";
            m_email.PlaceholderColor = Color.LightGray;
            m_email.Unfocused += M_email_Unfocused;

            m_password.Placeholder = "Password(min length 6)";
            m_password.IsPassword = true;
            //m_password.Unfocused += M_password_Unfocused;
            m_password.PlaceholderColor = Color.LightGray;

            m_verifyPw.Placeholder = "re-enter Password";
            m_verifyPw.PlaceholderColor = Color.LightGray;
            //m_verifyPw.Unfocused += M_password_Unfocused;
            m_verifyPw.IsPassword = true;

            m_background.Placeholder = "Background";
            m_background.PlaceholderColor = Color.Gray;

            m_location.Placeholder = "Location";
            m_location.PlaceholderColor = Color.Gray;

            m_areasOfIntrest.Placeholder = "Areas of Interest";
            m_areasOfIntrest.PlaceholderColor = Color.Gray;

            m_picker.Title = "Choose Account Type";
            m_picker.BackgroundColor = Color.White;
            m_picker.TextColor = Color.Black;
            m_picker.VerticalOptions = LayoutOptions.CenterAndExpand;
            m_picker.HorizontalOptions = LayoutOptions.CenterAndExpand;
            m_picker.Items.Add("Supervisor");
            m_picker.Items.Add("Supervisee");
            m_picker.SelectedIndex = 1;
            m_picker.SelectedIndexChanged += M_picker_SelectedIndexChanged;

            m_distance.Title = "Distance Supervision";
            m_distance.Items.Add("Distance Supervision: Yes");
            m_distance.Items.Add("Distance Supervision: No");
            m_distance.BackgroundColor = Color.White;
            m_distance.TextColor = Color.Black;
            m_distance.VerticalOptions = LayoutOptions.CenterAndExpand;
            m_distance.HorizontalOptions = LayoutOptions.CenterAndExpand;
            m_distance.SelectedIndexChanged += M_distance_SelectedIndexChanged;
            m_distance.SelectedIndex = 1;

            m_certificationNumber.Placeholder = "Certification Number";
            m_certificationNumber.PlaceholderColor = Color.Gray;
            
            m_certificationDate.Format = "d";
            m_certificationDate.VerticalOptions = LayoutOptions.CenterAndExpand;

            m_supervisionCompleted.Format = "d";
            m_supervisionCompleted.VerticalOptions = LayoutOptions.CenterAndExpand;


            Content = new ScrollView() { Content=new StackLayout()
                {
                    VerticalOptions = LayoutOptions.CenterAndExpand,
                    HorizontalOptions = LayoutOptions.CenterAndExpand,
                    Children = {
                                m_picker,
                                m_fName,
                                m_lName,
                                m_email,
                                m_password,
                                m_verifyPw,
                                m_background,
                                m_location,
                                m_areasOfIntrest,
                                m_signUp
                               }

                }
            };
        }

        private void M_password_Unfocused(object sender, FocusEventArgs e)
        {
            if(m_verifyPw.Text !=null && m_password.Text !=null && m_verifyPw.Text != "" && m_password.Text != "")
            {
                if (m_verifyPw.Text != m_password.Text)
                {
                    DisplayAlert("Alert", "Passwords don't match ", "OK");
                }
            }
        }

        private void M_email_Unfocused(object sender, FocusEventArgs e)
        {
            if (m_email.Text != null && m_email.Text !="")
            {
                if (!Regex.IsMatch(m_email.Text.ToString(), @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase))
                {
                    //m_email.TextColor = Color.Red;
                    DisplayAlert("Alert", "Invalid Email", "OK");
                    return;
                }
                else
                {
                    m_email.TextColor = Color.Black;
                }
            }
        }
    
        private void M_distance_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(m_distance.SelectedItem.ToString() == "Yes")
            {
                m_distanceSupervision = true;
            }
            else
            {
                m_distanceSupervision = false;
            }
        }

        private void M_picker_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (m_picker.SelectedItem.ToString() == "Supervisee")
            {
                this.Content = new ScrollView()
                {
                    Content = new StackLayout()
                    {
                        VerticalOptions = LayoutOptions.CenterAndExpand,
                        HorizontalOptions = LayoutOptions.CenterAndExpand,
                        Children = {
                            m_picker,
                    m_fName,
                    m_lName,
                    m_email,
                    m_password,
                    m_verifyPw,
                    m_background,
                    m_location,
                    m_areasOfIntrest,
                    m_signUp

                    }
                    }
                };
            }
            else
            {
                Label DateCertified = new Label { Text = "Date Certified:", HorizontalOptions = LayoutOptions.CenterAndExpand };
                Label DateSupervisionCompleted = new Label { Text = "Date Supervision Completed:", HorizontalOptions = LayoutOptions.CenterAndExpand };

                this.Content = new ScrollView()
                    {
                        Content = new StackLayout()
                        {
                            VerticalOptions = LayoutOptions.CenterAndExpand,
                            HorizontalOptions = LayoutOptions.CenterAndExpand,
                            Children = {
                                        m_picker,
                                        m_fName,
                                        m_lName,
                                        m_email,
                                        m_password,
                                        m_verifyPw,
                                        m_background,
                                        m_location,
                                        m_areasOfIntrest,
                                        m_certificationNumber,
                                        DateSupervisionCompleted,
                                        m_supervisionCompleted,
                                        DateCertified,
                                        m_certificationDate,
                                        m_distance,
                                        m_signUp
                                       }
                        }
                    };
            }
        }
        Label MakeLabel(string title)
        {
            Label temp = new Label();

            temp.Text = title + ":";

            return temp;
        }
        async void MakeAccount(object sender,EventArgs e)
        {
            if (m_picker.SelectedItem.ToString() == "Supervisee")
            {
                if (validateAccount()) //See if the information the user entered valid account information
                {

                    ExpandedUser user = new ExpandedUser();
                    user.FName = m_fName.Text;
                    user.LName = m_lName.Text;
                    user.Email = m_email.Text;
                    user.Location = m_location.Text;
                    user.AreaOfInterest = m_areasOfIntrest.Text;
                    user.Background = m_background.Text;

                    Task<HttpResponseMessage> responseMessage = PostData.postData(user, "postuser");
                    HttpStatusCode response = responseMessage.Result.StatusCode;
                    if (response == System.Net.HttpStatusCode.Created)
                    {
                        await DisplayAlert("Alert", "Account Created. Please check your email for validation link.", "OK");
                    }
                    else if (response == System.Net.HttpStatusCode.BadRequest)
                    {
                        await DisplayAlert("Alert", "Email is already in use.", "OK");
                    }
                    else
                    {
                        await DisplayAlert("Alert", "Sorry something went wrong when creating your account.", "OK");
                    }
                }
            }
            else
            {
                if (validateAccount())
                {
                    m_dateSupervisonCompleted = m_supervisionCompleted.Date;
                    m_dateCertified = m_certificationDate.Date;

                    SupervisorUser superuser = new SupervisorUser();
                    superuser.FName = m_fName.Text;
                    superuser.LName = m_lName.Text;
                    superuser.Email = m_email.Text;
                    superuser.Location = m_location.Text;
                    superuser.AreaOfInterest = m_areasOfIntrest.Text;
                    superuser.Background = m_background.Text;
                    superuser.CertificationNumber = m_certificationNumber.Text;
                    superuser.DateCertified = m_dateCertified;
                    superuser.DateCompletedSupervision = m_dateSupervisonCompleted;
                    superuser.DistanceSupervision = m_distanceSupervision;

                    Task<HttpResponseMessage> responseMessage = PostData.postData(superuser, "postsupervisor");

                    HttpStatusCode response = responseMessage.Result.StatusCode;
                    if (response == System.Net.HttpStatusCode.Created)
                    {
                        await DisplayAlert("Alert", "Account Created. Please check your email for validation link.", "OK");
                    }
                    else if (response == System.Net.HttpStatusCode.BadRequest)
                    {
                        await DisplayAlert("Alert", "Email is already in use.", "OK");
                    }
                    else 
                    {
                        await DisplayAlert("Alert", "Sorry something went wrong when creating your account.", "OK");
                    }
                }
            }

        }
        /**************************************
        Purpose: Check if the information the User entered was valid

        Returns true if the info was valid

        Returns false if the information wasn't valid and
        Displays message depending on what was invalid

        Function is called everytime a user is tried to be created.
        **************************************/
        private bool validateAccount()
        {
            if(m_fName.Text == null || m_fName.Text=="")
            {
                DisplayAlert("Alert", "Please enter a first name", "OK");
                return false;

            }
            if (m_lName.Text == null || m_lName.Text=="")
            {
                DisplayAlert("Alert", "Please enter a last name", "OK");
                return false;

            }
            if (m_email.Text == null)
            {
                DisplayAlert("Alert", "Must enter an email", "OK");
                return false;
            }
            else
            {
                if (!Regex.IsMatch(m_email.Text.ToString(), @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase))
                {
                    DisplayAlert("Alert", "Invalid Email", "OK");
                    return false;
                }
            }
            if (m_password.Text == null)
            {
                DisplayAlert("Alert", "Must enter a password with at least 6 letters", "OK");
                return false;
            }
            else
            { //Check if password is valid
                if (m_password.Text != m_verifyPw.Text)
                {
                    DisplayAlert("Alert", "Passwords don't match ", "OK");
                    return false;
                }
                if (m_password.Text.ToString().Length < 6)
                {
                    DisplayAlert("Alert", "Password is not long enough must be 6 characters of length", "OK");
                    return false;
                }
            }
            if(m_background.Text == null || m_background.Text == "")
            {
                DisplayAlert("Alert", "Must enter a background", "OK");
                return false;
            }
            if (m_location.Text == null || m_location.Text == "")
            {
                DisplayAlert("Alert", "Must enter a Location", "OK");
                return false;
            }
            if (m_areasOfIntrest.Text == null || m_areasOfIntrest.Text == "")
            {
                DisplayAlert("Alert", "Must enter a area of inerest.", "OK");
                return false;
            }
            if (m_picker.SelectedIndex.ToString()=="Supervisor")
            {
                if(m_certificationNumber==null || m_certificationNumber.Text=="")
                {
                    DisplayAlert("Alert", "Must enter a certification number.", "OK");
                    return false;
                }
                if(m_dateSupervisonCompleted>=DateTime.Now)
                {
                    DisplayAlert("Alert", "Date you completed supervision must be before Today.", "OK");
                    return false;
                }
                if(m_dateCertified <= m_dateSupervisonCompleted)
                {
                    DisplayAlert("Alert", "Date you were certified must be before you completed supervision", "OK");
                    return false;
                }
            }
            return true;
        }
    }
}