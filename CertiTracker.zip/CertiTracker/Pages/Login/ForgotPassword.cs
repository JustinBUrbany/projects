﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Xamarin.Forms;

namespace CertiTracker.Pages
{
    public class ForgotPassword : ContentPage
    {
        Entry m_email = new Entry();
        Button m_sendEmail = new Button();

        public ForgotPassword()
        {
            this.Title = "Forgot Password";
           

            m_email.Placeholder = "Email";

            m_sendEmail.Text = "Send reset to Email";
            m_sendEmail.TextColor = Color.White;
            m_sendEmail.BackgroundColor = Color.FromRgb(0, 160, 255);
            m_sendEmail.Clicked += M_sendEmail_Clicked;
            

            Content = new StackLayout
            {
                HorizontalOptions = LayoutOptions.CenterAndExpand,
                VerticalOptions = LayoutOptions.CenterAndExpand,
                Children = {
                 
                    m_email,
                    m_sendEmail
                }
            };
        }

        async private void M_sendEmail_Clicked(object sender, EventArgs e)
        {
            if (m_email.Text != null && m_email.Text != "")
            {
                if (!Regex.IsMatch(m_email.Text.ToString(), @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase))
                {
                    await DisplayAlert("Alert", "Invalid Email", "OK");
                    return;
                }
                else
                {
                    await Navigation.PushAsync(new ConformationChangePassword(m_email.Text));
                }
            }
        }
    }
}