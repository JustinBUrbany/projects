﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Xamarin.Forms;

namespace CertiTracker.Pages
{
    public class ConformationChangePassword : ContentPage
    {
        String m_email;
        Entry m_conformation = new Entry();
        Entry m_password = new Entry();
        Entry m_verifypw = new Entry();
        Button m_submitConformation = new Button();

        public ConformationChangePassword(String email)
        {
            this.Title = "Reset Password";
            m_email = email;
            m_conformation.Placeholder = "*Conformation code from Email";
            m_conformation.PlaceholderColor = Color.Gray;

            m_password.Placeholder = "*New password(min length 6)";
            m_password.PlaceholderColor = Color.Gray;
            m_password.IsPassword = true;

            m_verifypw.Placeholder = "*re-enter password";
            m_verifypw.PlaceholderColor = Color.Gray;
            m_verifypw.IsPassword = true;

            m_submitConformation.Text = "Send reset to Email";
            m_submitConformation.TextColor = Color.White;
            m_submitConformation.BackgroundColor = Color.FromRgb(0, 160, 255);
            m_submitConformation.Clicked += M_submitConformation_Clicked;


            Content = new StackLayout
            {
                
                HorizontalOptions = LayoutOptions.CenterAndExpand,
                VerticalOptions = LayoutOptions.CenterAndExpand,
                Children = {
                        m_conformation,
                        m_password,
                        m_verifypw,
                        m_submitConformation
                }
                
            };
        }

        private void M_submitConformation_Clicked(object sender, EventArgs e)
        {
            if(m_conformation.Text == null || m_conformation.Text=="")
            {
                DisplayAlert("Alert", "No Conformation Code", "OK");
                return;
            }
            if (m_password.Text == null || m_password.Text=="")
            {
                DisplayAlert("Alert", "Must enter a password with at least 6 letters", "OK");
                return;
            }
            if (m_password.Text.ToString().Length < 6)
            {
                DisplayAlert("Alert", "Password is not long enough must be 6 characters of length", "OK");
                return;
            }
            if (m_password.Text != m_verifypw.Text)
            {
                DisplayAlert("Alert", "Passwords don't match ", "OK");
                return;
            }
            //We need to send a conformation code to see if the email and conformation is correct and if is correct then change the password in the database accordingly
        }
    }
}