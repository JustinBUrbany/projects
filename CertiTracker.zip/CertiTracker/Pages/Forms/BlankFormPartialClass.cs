﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using CertiTracker.Utility;
using DataContainers;
using DataContainers.Forms;
using Xamarin.Forms;
using DataContainers.Forms.FormFields;

namespace CertiTracker.Pages.Forms
{
    public partial class BlankForm
    {
        List<ItemCategoryData> itemCategoryData;
        Picker pickCompetecyCategory = new Picker();

        Picker pickCompetency = new Picker();
        ListView ListViewOfAppliedCompetencies = new ListView();

        List<FormCompetency> ListOfAppliedCompetencies = new List<FormCompetency>();
        ObservableCollection<string> ListOfAppliedCompetenciesStrings = new ObservableCollection<string>();

        DatePicker pickCompetencyDate = new DatePicker();


        Picker pickCompetencyTraining = new Picker();

        Picker pickHoursSupervised = new Picker();
        DatePicker datePicker = new DatePicker();

        ListView ListViewOfSupervisedHours = new ListView();
        List<SupervisionTime> m_supervisionTimes = new List<SupervisionTime>();
        ObservableCollection<string> ListOfSupervisedHoursStrings = new ObservableCollection<string>();
        public ContentPage MakeCompetencies()
        {
            Button addCompetency = new Button() { Text = "Add Competency" };
            addCompetency.Pressed += OnCompetencyItemAdded;

            //itemCategoryData = GetData.getData<List<ItemCategoryData>>("/Forms/CompList");

            pickCompetecyCategory.SelectedIndexChanged += OnCompetencyCategoryChanged;
            GetCompetencyCategories();
            pickCompetecyCategory.SelectedIndex = 0;

            CreateCompetencyTrainingPicker();


            ListViewOfAppliedCompetencies.SeparatorVisibility = SeparatorVisibility.None;
            ListViewOfAppliedCompetencies.ItemsSource = ListOfAppliedCompetenciesStrings;


            return new ContentPage()
            {
                Content = new StackLayout
                {
                    Children =
                    {
                        pickCompetecyCategory,
                        pickCompetency,
                        pickCompetencyTraining,
                        pickCompetencyDate,
                        addCompetency,
                        ListViewOfAppliedCompetencies
                    }
                },
                Title = "Competencies"
            };
        }

        public ContentPage MakeCompetenciesFilled()
        {

            Button addCompetency = new Button() { Text = "Add Competency" };
            addCompetency.Pressed += OnCompetencyItemAdded;

            //itemCategoryData = GetData.getData<List<ItemCategoryData>>("/Forms/CompList");

            pickCompetecyCategory.SelectedIndexChanged += OnCompetencyCategoryChanged;
            GetCompetencyCategories();
            pickCompetecyCategory.SelectedIndex = 0;

            CreateCompetencyTrainingPicker();


            ListViewOfAppliedCompetencies.SeparatorVisibility = SeparatorVisibility.None;
            ListViewOfAppliedCompetencies.ItemsSource = ListOfAppliedCompetenciesStrings;

            List<Entry> competencies = new List<Entry>();
            for(int i =0; i <m_form.FormCompetencies.Count; ++i)
            {
                ListOfAppliedCompetenciesStrings.Add(GetCompetency(m_form.FormCompetencies[i].CompetencyID));
            }

            return new ContentPage()
            {
                Content = new StackLayout
                {
                    Children =
                    {
                        pickCompetecyCategory,
                        pickCompetency,
                        pickCompetencyTraining,
                        pickCompetencyDate,
                        addCompetency,
                        ListViewOfAppliedCompetencies
                    }
                },
                Title = "Competencies"
            };
            
        }
        string GetCompetency(int Competency)
        {
            string newCompetency = "";
            foreach(ItemCategoryData ic in itemCategoryData)
            {
                if(ic.CategoryType==0 && ic.CategoryItemID==Competency)
                {
                    ListOfAppliedCompetencies.Add(new FormCompetency(ic.CategoryItemID)); //Add Date Add The other Item Category Data (4)
                    newCompetency = ic.ItemTitle + " " + ic.ItemBody;
                    break;
                }
            }
            return newCompetency;
        }

        StackLayout MakeSupervisedHours()
        {
            Button addSupervisedHours = new Button() { Text = "Add Supervision Dates and Times" };
            addSupervisedHours.Pressed += OnSupervisedHourItemAdded;

            for (int i = 1; i < 13; i++)
            {
                pickHoursSupervised.Items.Add(i.ToString());
            }

            pickHoursSupervised.SelectedIndex = 0;
            ListViewOfSupervisedHours.SeparatorVisibility = SeparatorVisibility.None;
            ListViewOfSupervisedHours.ItemsSource = ListOfSupervisedHoursStrings;

            return new StackLayout()
            {
                Children =
                {
                    datePicker,
                    pickHoursSupervised,
                    addSupervisedHours,
                    ListViewOfSupervisedHours
                }
            };
        }

        void GetCompetencyCategories() //Get all the competencies
        {
            List<string> competenciesCategory = new List<string>();
            foreach (ItemCategoryData ic in itemCategoryData)
            {
                if (ic.CategoryType == 0 && !competenciesCategory.Contains(ic.ItemTitle[0].ToString()))
                {
                    competenciesCategory.Add(ic.ItemTitle[0].ToString());
                }
            }

            foreach (string s in competenciesCategory)
            {
                pickCompetecyCategory.Items.Add(s);
            }
        }

        void OnCompetencyItemAdded(object sender, EventArgs e) 
        {
            foreach (ItemCategoryData ic in itemCategoryData)
            {
                if (pickCompetency.SelectedItem.ToString() == (ic.ItemTitle + " " + ic.ItemBody))
                {
                    if (!ContainsCompetency(ListOfAppliedCompetencies, ic))
                    {
                        ListOfAppliedCompetencies.Insert(0,new FormCompetency(ic.CategoryItemID));
                        ListOfAppliedCompetenciesStrings.Insert(0, ic.ItemTitle + " " + ic.ItemBody);
                    }
                    break;
                }
            }
        }

        void OnCompetencyCategoryChanged(object sender, EventArgs e)
        {
            pickCompetency.Items.Clear();
            string firstletter = pickCompetecyCategory.SelectedItem.ToString();
            foreach (ItemCategoryData ic in itemCategoryData)
            {
                if (ic.CategoryType == 0 && ic.ItemTitle[0].ToString() == firstletter)
                {
                    pickCompetency.Items.Add(ic.ItemTitle + " " + ic.ItemBody);
                }
            }
            pickCompetency.SelectedIndex = 0;
        }

        bool ContainsCompetency(List<FormCompetency> competency, ItemCategoryData ic)
        {
            
            foreach(FormCompetency comp in competency)
            {
                if(comp.CompetencyID == ic.CategoryItemID)
                {
                    return true;
                }
               
            }
            return false;
        }

        void OnSupervisedHourItemAdded(object sender, EventArgs e)
        {
            if (!ListOfSupervisedHoursStrings.Contains(datePicker.Date.ToString("d") + " " + pickHoursSupervised.SelectedItem + " hour(s)"))
            {
                m_supervisionTimes.Add(new SupervisionTime(datePicker.Date, TimeSpan.FromHours(Convert.ToInt16(pickHoursSupervised.SelectedItem.ToString())).Ticks));
                //m_supervisionTimes.Add(new SupervisionTime(datePicker.Date, Convert.ToInt16(pickHoursSupervised.SelectedItem.ToString())));
                ListOfSupervisedHoursStrings.Add(datePicker.Date.ToString("d") + " " + pickHoursSupervised.SelectedItem + " hour(s)");
            }
        }

        void CreateCompetencyTrainingPicker()
        {
            foreach (ItemCategoryData ic in itemCategoryData)
            {
                if(ic.CategoryType == 4)
                {
                    pickCompetencyTraining.Items.Add(ic.ItemTitle);
                }
                pickCompetencyTraining.SelectedIndex = 0;
            }
        }
    }
}
