﻿/************************************************************ 
* Author: Justin Urbany 
* Created: February 2, 2018 
*  
* This class is to create a blank form so Users can create a
* new form when they need too
*  
*************************************************************/
using CertiTracker.Utility;
using DataContainers;
using DataContainers.Forms;
using DataContainers.Users;
using System;
using System.Collections.Generic;

using Xamarin.Forms;
using DataContainers.Relationships;
using System.Threading.Tasks;

namespace CertiTracker.Pages.Forms
{
    public partial class BlankForm : CertiTrackerTabbedPage
    {
        //Header data members
        Entry m_Superviseefullname;
        Entry m_Supervisorfullname;
        DatePicker m_startdate = new DatePicker();
        DatePicker m_endDate = new DatePicker();
        Entry m_comments;

        //Activities data members
        Entry m_A;
        Entry m_A1;
        Entry m_A2;
        Entry m_A3;
        Entry m_A4;
        Entry m_A5;
        Entry m_A6;
        Entry m_B;
        Entry m_C;
        Entry m_hours;
        Entry m_percentage;

        //Supervision Characteristics
        List<Switch> m_characteristics = new List<Switch>();
        Switch m_clientPrivacyProtected;
        Switch m_supervisionDiscussionandFeedback;
        Switch m_specificClientDiscussed;
        Switch m_observationOfSuperviseeVideo;
        Switch m_observationOfSuperviseeSitu;
        Switch m_BACBTaskList;
        Switch m_readings;

        //Grades 
        List<Picker> m_evalgrades = new List<Picker>();
        List<string> m_skillstring = new List<string>();

        Picker m_ArriveonTime=new Picker();
        Picker m_DemonstratesInteractionsWithClients = new Picker();
        Picker m_DemonstratesInteractionsWithOtherServiceProviders = new Picker();
        Picker m_MaintainsAppropriateInteraction = new Picker();
        Picker m_MaintainsAppropriateAttireandDeameanor = new Picker();
        Picker m_IntiatesProfessionalSelfImprovement = new Picker();
        Picker m_AcceptsSupervisoryFeedback = new Picker();
        Picker m_SeekSupervisionAppropriately = new Picker();
        Picker m_DemonstratesTimelySubmission = new Picker();
        Picker m_DemonstratesEffectWrittenCommunication = new Picker();
        Picker m_DemonstratesEffectOralCommunication = new Picker();
        Picker m_DemonstatesAcquisitionofTarget = new Picker();
        Picker m_SelfDetectsPersonalLimitations = new Picker();
        Picker m_Overall = new Picker();

        Picker m_Type = new Picker();
        Picker m_TypeofExperience = new Picker();
        Button m_Save = new Button();
        Button m_Submit = new Button();

        ContentPage m_headerPage;
        ContentPage m_behaviorActivitiesPage;
        ContentPage m_characteristcsofSupervisionPage;
        ContentPage m_skillPage;
        ContentPage m_competencies;

        ExpandedUser m_supervisee;
        ExpandedUser m_supervisor;

        string m_superviseeid;
        string m_supervisoruserid;
        string m_supervisorid;

        int m_relationshipid;

        //Used to be able to remove this element at the end of buildpage;
        ContentPage activityIndicator = null;


        public BlankForm(string superviseeid, string supervisoruserid, string supervisorid = "")
        {
            m_superviseeid = superviseeid;
            m_supervisoruserid = supervisoruserid;
            m_supervisorid = supervisorid;

            AddActitivtyIndicator();

            Task.Run(() => GetPageData());
        }


        CompleteForm m_form = null;
        string m_formId = null;

        public BlankForm(string formId)
        {
            m_formId = formId;

            AddActitivtyIndicator();

            Task.Run(() => GetPageData());
        }

        public void AddActitivtyIndicator()
        {
            StackLayout pagelayout = new StackLayout()
            {
                VerticalOptions = LayoutOptions.CenterAndExpand
            };
            pagelayout.Children.Add(new ActivityIndicator() { IsRunning = true, Color = Color.FromRgb(0, 160, 255) });

            activityIndicator = new ContentPage() { Content = pagelayout };
            Children.Add(activityIndicator);
        }

        public override void GetPageData()
        {
            try
            {
                if(m_formId != null)
                {
					m_form = GetData.getData<CompleteForm>("/Forms/Get1Form/" + m_formId);

                    m_relationshipid = m_form.RelationshipID;
                    BaseRelationship relationship = GetData.getData<BaseRelationship>("/GetRelationship/RelationshipID/" + m_relationshipid.ToString());
                    m_superviseeid = relationship.SuperviseeID.ToString();
                    m_supervisorid = relationship.SupervisorID.ToString();

                    m_supervisee = GetData.getData<ExpandedUser>("/GetUser/" + m_superviseeid);
                    m_supervisor = GetData.getData<ExpandedUser>("/GetSupervisorsUserID/" + m_supervisorid);
                    m_supervisoruserid = m_supervisor.UID.ToString();
                }
                else
                {
                    m_supervisee = GetData.getData<ExpandedUser>("/GetUser/" + m_superviseeid);

                    if (m_supervisorid != "")
                    {
                        m_supervisor = GetData.getData<ExpandedUser>("/GetUser/" + m_supervisoruserid);
                    }

                    m_relationshipid = GetData.getData<int>("/GetRelationship/" + m_superviseeid + "/" + m_supervisorid);
                }

				itemCategoryData = GetData.getData<List<ItemCategoryData>>("/Forms/CompList");
            }
            catch (CertiTrackerException e)
            {
                errorLabel = new Label() { Text = e.Message };
            }

            Action action = BuildPage;
            Device.BeginInvokeOnMainThread(action);
        }

        void TypeOfFormChanged(object sender ,EventArgs e)
        {
            this.Children.Remove(m_behaviorActivitiesPage);
            this.Children.Remove(m_characteristcsofSupervisionPage);
            this.Children.Remove(m_skillPage);
            this.Children.Remove(m_competencies);
            m_evalgrades.Clear();
            if(m_Type.SelectedIndex==0)
            {
                m_behaviorActivitiesPage = new ContentPage()
                {
                    Content = new ScrollView()
                    {
                        Content = MakeBehaviorActivities()
                    },
                    Title = "Behavior Activities"
                };
                Children.Add(m_behaviorActivitiesPage);

                m_characteristcsofSupervisionPage = new ContentPage()
                {
                    Content = new ScrollView()
                    {
                        Content = MakeCharacteristcsofSupervisionConducted()
                    },
                    Title = "Supervision Conducted"
                };
                Children.Add(m_characteristcsofSupervisionPage);

                m_skillPage = new ContentPage()
                {
                    Content = new ScrollView()
                    {
                        Content = MakeSkills()
                    },
                    Title = "Skills"
                };
                Children.Add(m_skillPage);
                Children.Add(m_competencies);
            }
            else
            {
                m_behaviorActivitiesPage = new ContentPage()
                {
                    Content = new ScrollView()
                    {
                        Content = MakeBehaviorActivities()
                    },
                    Title = "Behavior Activities"
                };
                Children.Add(m_behaviorActivitiesPage);

                m_characteristcsofSupervisionPage = new ContentPage()
                {
                    Content = new ScrollView()
                    {
                        Content = MakeCharacteristcsofSupervisionConducted()
                    },
                    Title = "Supervision Conducted"
                };
                Children.Add(m_characteristcsofSupervisionPage);

                m_skillPage = new ContentPage()
                {
                    Content = new ScrollView()
                    {
                        Content = MakeSkills()
                    },
                    Title = "Skills"
                };
                Children.Add(m_skillPage);
                Children.Add(m_competencies);

            }
        }


        Grid MakeHeader()
        {
            Grid header = new Grid();

            header.Children.Add(new Frame { Content = MakeLabel("Supervisee:"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 0);
            m_Superviseefullname = new Entry { Text = m_supervisee.FName + " " + m_supervisee.LName };//MakeEntry(m_supervisee.FName + " " + m_supervisee.LName);
            header.Children.Add(m_Superviseefullname, 1, 0);

            header.Children.Add(new Frame { Content = MakeLabel("Supervisor:"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 1);
            m_Supervisorfullname = new Entry { Text = m_supervisor.FName + " " + m_supervisor.LName };// MakeEntry(m_supervisor.FName + " " + m_supervisee.LName);
            header.Children.Add(m_Supervisorfullname, 1, 1);

            header.Children.Add(new Frame { Content = MakeLabel("Start Date:"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 2);
            m_startdate = new DatePicker { Format = "d", VerticalOptions = LayoutOptions.CenterAndExpand };
            header.Children.Add(m_startdate, 1, 2);

            header.Children.Add(new Frame { Content = MakeLabel("End Date:"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 3);
            m_endDate =  new DatePicker { Format = "d", VerticalOptions = LayoutOptions.CenterAndExpand };
            header.Children.Add(m_endDate, 1, 3);

            return header;
        }

        Grid MakeBehaviorActivities()
        {
            Grid BehaviorActivities = new Grid();
            BehaviorActivities.Padding = new Thickness(0, 30);

            BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A. Total number of individual experience hours accumulated"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 0);
            m_A = MakeEntry("A. hours");
            BehaviorActivities.Children.Add(m_A, 1, 0);

            BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A1. Direct implementation\nof theraputic programming"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 1);
            m_A1 = MakeEntry("A1. hours");
            BehaviorActivities.Children.Add(m_A1, 1, 1);

            BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A2. Conducting assements\nrelated to behavioral intervention"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 2);
            m_A2 = MakeEntry("A2. hours");
            BehaviorActivities.Children.Add(m_A2, 1, 2);

            BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A3.Designing and monitoring skill acquistion / behavior reduction prgrams"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 3);
            m_A3 = MakeEntry("A3. hours");
            BehaviorActivities.Children.Add(m_A3, 1, 3);

            BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A4. Overseeing the implementation of behavior-analytic programs by others: "), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 4);
            m_A4 = MakeEntry("A4. hours");
            BehaviorActivities.Children.Add(m_A4, 1, 4);

            BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A5. Training, designing behavioral systems, or performance management"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 5);
            m_A5 = MakeEntry("A5. hours");
            BehaviorActivities.Children.Add(m_A5, 1, 5);

            BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A6. Other activities such as attending planning meetings regarding the behavior analytic" +
                                                                            "program, reviewing relevant literature, and talking to individuals about a program"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 6);
            m_A6 = MakeEntry("A6. hours");
            BehaviorActivities.Children.Add(m_A6, 1, 6);


            BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("B.Number of individual supervision hours accumulated\n(number of individual supervision hours)"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 7);
            m_B = MakeEntry("B. hours");
            BehaviorActivities.Children.Add(m_B, 1, 7);

            if (m_Type.SelectedIndex == 0)
            {
                BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("C.Total experience hours accumulated this period"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 8);
                m_hours = MakeEntry("C.hours");
                BehaviorActivities.Children.Add(m_hours, 1, 8);

                BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("What percentage of hours were spent in DIRECT intervention?"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 9);
                m_percentage = MakeEntry("(LineA1/C*100)");
                BehaviorActivities.Children.Add(m_percentage, 1, 9);
            }
            else
            {
                BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("C. Number of group supervision hours accumulated"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 8);
                m_C = MakeEntry("C.hours");
                BehaviorActivities.Children.Add(m_C, 1, 8);

                BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("D.Total experience hours accumulated this period"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 9);
                m_hours = MakeEntry("D.Hours(Add A-C)");
                BehaviorActivities.Children.Add(m_hours, 1, 9);

                BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("What percentage of hours were spent in DIRECT intervention?"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 10);
                m_percentage = MakeEntry("(LineA1/C*100)");
                BehaviorActivities.Children.Add(m_percentage, 1, 10);
            }

            return BehaviorActivities;
        }

        Grid MakeBehaviorActivitiesFilled()
        {
            Grid BehaviorActivities = new Grid();
            BehaviorActivities.Padding = new Thickness(0, 30);

            BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A. Total number of individual experience hours accumulated"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 0);

            BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A1. Direct implementation\nof theraputic programming"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 1);

            BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A2. Conducting assements\nrelated to behavioral intervention"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 2);

            BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A3.Designing and monitoring skill acquistion / behavior reduction prgrams"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 3);

            BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A4. Overseeing the implementation of behavior-analytic programs by others: "), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 4);

            BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A5. Training, designing behavioral systems, or performance management"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 5);

            BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            BehaviorActivities.Children.Add(new Frame
            {
                Content = MakeLabel("A6. Other activities such as attending planning meetings regarding the behavior analytic" +
                                                                            "program, reviewing relevant literature, and talking to individuals about a program"),
                BackgroundColor = Color.FromRgb(0, 160, 255)}/*End of that other bracket*/, 0, 6);

            BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("B.Number of individual supervision hours accumulated\n(number of individual supervision hours)"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 7);

            if (m_Type.SelectedIndex == 0)
            {
                BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("C.Total experience hours accumulated this period"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 8);


                BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("What percentage of hours were spent in DIRECT intervention?"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 9);

            }
            else
            {
                BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("C. Number of group supervision hours accumulated"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 8);


                BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("D.Total experience hours accumulated this period"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 9);


                BehaviorActivities.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("What percentage of hours were spent in DIRECT intervention?"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 10);

            }
            m_A = GetHours(m_form.ExpHours, 0);
            BehaviorActivities.Children.Add(m_A, 1, 0);
            m_A1 = GetHours(m_form.ExpHours, 1);
            BehaviorActivities.Children.Add(m_A1, 1, 1);
            m_A2 = GetHours(m_form.ExpHours, 2);
            BehaviorActivities.Children.Add(m_A2, 1, 2);
            m_A3 = GetHours(m_form.ExpHours, 3);
            BehaviorActivities.Children.Add(m_A3, 1, 3);
            m_A4 = GetHours(m_form.ExpHours, 4);
            BehaviorActivities.Children.Add(m_A4, 1, 4);
            m_A5 = GetHours(m_form.ExpHours, 5);
            BehaviorActivities.Children.Add(m_A5, 1, 5);
            m_A6 = GetHours(m_form.ExpHours, 6);
            BehaviorActivities.Children.Add(m_A6, 1, 6);
            m_B = GetHours(m_form.ExpHours, 7);
            BehaviorActivities.Children.Add(m_B, 1, 7);

            if (m_Type.SelectedIndex == 0)
            {
                m_hours = MakeEntryFilled(m_form.GetDuration().Hours.ToString());
                BehaviorActivities.Children.Add(m_hours, 1, 8);

                double calculation = (m_form.ExpHours[1].GetDuration().TotalHours / m_form.GetDuration().TotalHours) * 100;
                m_percentage = MakeEntryFilled(calculation.ToString("F") + "%");
                BehaviorActivities.Children.Add(m_percentage, 1, 9);
            }
            else
            {
                m_C = MakeEntryFilled(m_form.GetGroupHours().ToString());
                BehaviorActivities.Children.Add(m_C, 1, 8);

                m_hours = MakeEntryFilled(m_form.GetDuration().Hours.ToString());
                BehaviorActivities.Children.Add(m_hours, 1, 9);

                double calculation = (m_form.ExpHours[1].GetDuration().TotalHours / m_form.GetDuration().TotalHours) * 100;
                m_percentage = MakeEntryFilled(calculation.ToString("F") + "%");
                BehaviorActivities.Children.Add(m_percentage, 1, 10);
            }


            return BehaviorActivities;
        }

        Grid MakeCharacteristcsofSupervisionConducted()
        {
            Grid characteristics = new Grid();
            characteristics.Padding = new Thickness(0, 20);

			characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Characteristics" } }, 0, 0);
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Check all that apply" } }, 1, 0);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "BACB Task List Covered" } }, 0, 1);
            m_BACBTaskList = new Switch { IsToggled = false };
            characteristics.Children.Add(m_BACBTaskList, 1, 1);
            m_characteristics.Add(m_BACBTaskList);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content =  new Label { Text = "Client privacy protected" } }, 0, 2);
            m_clientPrivacyProtected = new Switch { IsToggled = false };
            characteristics.Children.Add(m_clientPrivacyProtected, 1, 2);
            m_characteristics.Add(m_clientPrivacyProtected);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Supervisory discussion and feedback" } }, 0, 3);
            m_supervisionDiscussionandFeedback = new Switch { IsToggled = false };
            characteristics.Children.Add(m_supervisionDiscussionandFeedback, 1, 3);
            m_characteristics.Add(m_supervisionDiscussionandFeedback);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Specific client(s) discussed" } }, 0, 4);
            m_specificClientDiscussed = new Switch { IsToggled = false };
            characteristics.Children.Add(m_specificClientDiscussed, 1, 4);
            m_characteristics.Add(m_specificClientDiscussed);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Observation of supervisee(video)" } }, 0, 5);
            m_observationOfSuperviseeVideo = new Switch { IsToggled = false };
            characteristics.Children.Add(m_observationOfSuperviseeVideo, 1, 5);
            m_characteristics.Add(m_observationOfSuperviseeVideo);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Observation of supervisee(situ)" } }, 0, 6);
            m_observationOfSuperviseeSitu = new Switch { IsToggled = false };
            characteristics.Children.Add(m_observationOfSuperviseeSitu, 1, 6);
            m_characteristics.Add(m_observationOfSuperviseeSitu);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Readings" } }, 0, 7);
            m_readings = new Switch { IsToggled = false };
            characteristics.Children.Add(m_readings, 1, 7);
            m_characteristics.Add(m_readings);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "List Readings" } }, 0, 8);
            characteristics.Children.Add(new Entry { Placeholder = "List of Readings" }, 1, 8);

            characteristics.Children.Add(MakeSupervisedHours(),0,2,9,10);

            return characteristics;

        }


        Grid MakeCharacteristcsofSupervisionConductedFilled()
        {
            Grid characteristics = new Grid();
            characteristics.Padding = new Thickness(0, 20);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Characteristics" } }, 0, 0);
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Check all that apply" } }, 1, 0);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "BACB Task List Covered" } }, 0, 1);
            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Client privacy protected" } }, 0, 2);
            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Supervisory discussion and feedback" } }, 0, 3);
            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Specific client(s) discussed" } }, 0, 4);
            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Observation of supervisee(video)" } }, 0, 5);
            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Observation of supervisee(situ)" } }, 0, 6);
            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Readings" } }, 0, 7);
            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "ListReadings" } }, 0, 8);

            m_BACBTaskList= new Switch { IsToggled = false };
            m_characteristics.Add(m_BACBTaskList);
            m_clientPrivacyProtected = new Switch { IsToggled = false };
            m_characteristics.Add(m_clientPrivacyProtected);
            m_supervisionDiscussionandFeedback= new Switch { IsToggled = false };
            m_characteristics.Add(m_supervisionDiscussionandFeedback);
            m_specificClientDiscussed = new Switch { IsToggled = false };
            m_characteristics.Add(m_specificClientDiscussed);
            m_observationOfSuperviseeVideo = new Switch { IsToggled = false };
            m_characteristics.Add(m_observationOfSuperviseeVideo);
            m_observationOfSuperviseeSitu = new Switch { IsToggled = false };
            m_characteristics.Add(m_observationOfSuperviseeSitu);
            m_readings = new Switch { IsToggled = false };
            m_characteristics.Add(m_readings);


            int i = 0;
            int b = 0;
            while (m_form.FormCharacteristics.Count > i)
            {
                b = m_form.FormCharacteristics[i].Activity.CategoryItemID;
                switch (b)
                {
                    case (116)://BACB Task List Covered
                        m_BACBTaskList.IsToggled = true;
                        break;
                    case (117): //Client Privacy Protected
                        m_clientPrivacyProtected.IsToggled = true;
                        break;
                    case (118): //Supervisory discussion and feedback
                        m_supervisionDiscussionandFeedback.IsToggled = true;
                        break;
                    case (119): //Specific client(s) discussed
                        m_specificClientDiscussed.IsToggled = true;
                        break;
                    case (120): //Observation of supervisee(Video)
                        m_observationOfSuperviseeVideo.IsToggled = true;
                        break;
                    case (121): //Observation of supervisee (in Situ)
                        m_observationOfSuperviseeSitu.IsToggled = true;
                        break;
                    case (122): //Readings
                        m_readings.IsToggled = true;
                        characteristics.Children.Add(new Entry { Text = m_form.FormCharacteristics[i].ActivityText }, 1, 8);
                        break;
                    default:
                        break;
                }
                ++i;

            }

            characteristics.Children.Add(m_BACBTaskList, 1, 1);
            characteristics.Children.Add(m_clientPrivacyProtected, 1, 2);
            characteristics.Children.Add(m_supervisionDiscussionandFeedback, 1, 3);
            characteristics.Children.Add(m_specificClientDiscussed, 1, 4);
            characteristics.Children.Add(m_observationOfSuperviseeVideo, 1, 5);
            characteristics.Children.Add(m_observationOfSuperviseeSitu, 1, 6);
            characteristics.Children.Add(m_readings, 1, 7);

            characteristics.Children.Add(MakeSupervisedHours(), 0, 2, 9, 10);

            foreach(SupervisionTime s in m_form.SupervisionTimes)
            {
                m_supervisionTimes.Add(new SupervisionTime(s.Date, s.Duration));
                TimeSpan timeSpan = new TimeSpan(s.Duration);
                ListOfSupervisedHoursStrings.Add(s.Date.ToString("d") + " " + timeSpan.Hours + " hour(s)");
            }

            return characteristics;

        }




        Grid MakeSkills()
        {
            Grid skill = new Grid();
            m_ArriveonTime = SetPicker(skill, m_ArriveonTime, "Arrives on time for supervision", 0);
            if (m_Type.SelectedIndex == 0)
            {
                m_DemonstratesInteractionsWithClients = SetPicker(skill, m_DemonstratesInteractionsWithClients, "Demonstrates Appropriate interactions with clients/consumers", 1);
                m_DemonstratesInteractionsWithOtherServiceProviders = SetPicker(skill, m_DemonstratesInteractionsWithOtherServiceProviders, "Demonstrates appropriate interactions with other service providers", 2);
                m_MaintainsAppropriateInteraction = SetPicker(skill, m_MaintainsAppropriateInteraction, "Maintains appropriate interactions with co-workers", 3);
            }
            else
            {
                m_DemonstratesInteractionsWithClients = SetPicker(skill, m_DemonstratesInteractionsWithClients, "Demonstrates effective time management skills", 1);
                m_DemonstratesInteractionsWithOtherServiceProviders = SetPicker(skill, m_DemonstratesInteractionsWithOtherServiceProviders, "Demonstrates appropriate leadership skills", 2);
                m_MaintainsAppropriateInteraction = SetPicker(skill, m_MaintainsAppropriateInteraction, "Maintains appropriate interactions with group members", 3);
            }
            m_MaintainsAppropriateAttireandDeameanor = SetPicker(skill, m_MaintainsAppropriateAttireandDeameanor, "Maintains appropriate attire and demeanor", 4);
            m_IntiatesProfessionalSelfImprovement = SetPicker(skill, m_IntiatesProfessionalSelfImprovement, "Initiates professional self-improvement as needed", 5);
            m_AcceptsSupervisoryFeedback = SetPicker(skill, m_AcceptsSupervisoryFeedback, "Accepts supervisory feedback appropriately", 6);
            m_SeekSupervisionAppropriately = SetPicker(skill, m_SeekSupervisionAppropriately, "Seeks supervision appropriately", 7);
            m_DemonstratesTimelySubmission = SetPicker(skill, m_DemonstratesTimelySubmission, "Demonstrates timely submission of reports or projects", 8);
            m_DemonstratesEffectWrittenCommunication = SetPicker(skill, m_DemonstratesEffectWrittenCommunication, "Demonstrates effective written communication", 9);
            m_DemonstratesEffectOralCommunication = SetPicker(skill, m_DemonstratesEffectOralCommunication, "Demonstrates effective oral communication", 10);
            m_DemonstatesAcquisitionofTarget = SetPicker(skill, m_DemonstatesAcquisitionofTarget, "Demonstrates acquisition of target behavior-analytic skills", 11);
            m_SelfDetectsPersonalLimitations = SetPicker(skill, m_SelfDetectsPersonalLimitations, "Self-detects personal and professional limitations", 12);
            m_Overall = SetPicker(skill, m_Overall, "Overall evaluation of supervisee performance during this period", 13);

            return skill;
        }


        Grid MakeSkillsFilled()
        {
            Grid skill = new Grid();

            m_ArriveonTime = SetPicker(skill, m_ArriveonTime, "Arrives on time for supervision", 0);
            if (m_Type.SelectedIndex == 0)
            {
                m_DemonstratesInteractionsWithClients = SetPicker(skill, m_DemonstratesInteractionsWithClients, "Demonstrates Appropriate interactions with clients/consumers", 1);
                m_DemonstratesInteractionsWithOtherServiceProviders = SetPicker(skill, m_DemonstratesInteractionsWithOtherServiceProviders, "Demonstrates appropriate interactions with other service providers", 2);
                m_MaintainsAppropriateInteraction = SetPicker(skill, m_MaintainsAppropriateInteraction, "Maintains appropriate interactions with co-workers", 3);
            }
            else
            {
                m_DemonstratesInteractionsWithClients = SetPicker(skill, m_DemonstratesInteractionsWithClients, "Demonstrates effective time management skills", 1);
                m_DemonstratesInteractionsWithOtherServiceProviders = SetPicker(skill, m_DemonstratesInteractionsWithOtherServiceProviders, "Demonstrates appropriate leadership skills", 2);
                m_MaintainsAppropriateInteraction = SetPicker(skill, m_MaintainsAppropriateInteraction, "Maintains appropriate interactions with group members", 3);
            }
            m_MaintainsAppropriateAttireandDeameanor = SetPicker(skill, m_MaintainsAppropriateAttireandDeameanor, "Maintains appropriate attire and demeanor", 4);
            m_IntiatesProfessionalSelfImprovement = SetPicker(skill, m_IntiatesProfessionalSelfImprovement, "Initiates professional self-improvement as needed", 5);
            m_AcceptsSupervisoryFeedback = SetPicker(skill, m_AcceptsSupervisoryFeedback, "Accepts supervisory feedback appropriately", 6);
            m_SeekSupervisionAppropriately = SetPicker(skill, m_SeekSupervisionAppropriately, "Seeks supervision appropriately", 7);
            m_DemonstratesTimelySubmission = SetPicker(skill, m_DemonstratesTimelySubmission, "Demonstrates timely submission of reports or projects", 8);
            m_DemonstratesEffectWrittenCommunication = SetPicker(skill, m_DemonstratesEffectWrittenCommunication, "Demonstrates effective written communication", 9);
            m_DemonstratesEffectOralCommunication = SetPicker(skill, m_DemonstratesEffectOralCommunication, "Demonstrates effective oral communication", 10);
            m_DemonstatesAcquisitionofTarget = SetPicker(skill, m_DemonstatesAcquisitionofTarget, "Demonstrates acquisition of target behavior-analytic skills", 11);
            m_SelfDetectsPersonalLimitations = SetPicker(skill, m_SelfDetectsPersonalLimitations, "Self-detects personal and professional limitations", 12);
            m_Overall = MakePicker();
            for (int i = 0; i < m_Overall.Items.Count; i++)
            {
                if (m_form.FormGrade.ItemBody == m_Overall.Items[i])
                {
                    m_Overall.SelectedIndex = i;
                    break;
                }
            }
            skill.Children.Add(new Label { Text = "Overall evaluation of supervisee performance during this period" }, 0, 13);
            skill.Children.Add(m_Overall, 1, 13);
            return skill;
        }

        Picker SetPicker(Grid skill, Picker picker, string _s, int index)
        {
            picker = MakePicker();
            if (m_form != null)
            {
                SetSkillPicker(picker, index);
            }
            m_skillstring.Add(_s);
            skill.Children.Add(new Label() { Text = _s }, 0, index);
            skill.Children.Add(picker, 1, index);
            m_evalgrades.Add(picker);

            return picker;
        }

        Label MakeLabel(string Header, FontAttributes fontAttributes = FontAttributes.None)
        {
            Label ret = new Label();
            ret.Text = Header;
            ret.TextColor = Color.White;
            ret.LineBreakMode = LineBreakMode.WordWrap;
            ret.HorizontalOptions = LayoutOptions.End;
            ret.FontAttributes = fontAttributes;
            return ret;
        }

        Entry MakeEntry(string placeholder)
        {
            Entry temp = new Entry();
            temp.Placeholder = placeholder;
            temp.PlaceholderColor = Color.LightGray;

            return temp;
        }

        Entry MakeEntryFilled(string text)
        {
            Entry temp = new Entry();
            temp.Text = text;
            return temp;
        }

        void SetSkillPicker(Picker picker, int index)
        {
            for (int i = 0; i < picker.Items.Count; i++)
            {
                if (m_form.FormEvalFields[index].Grade.ItemBody == picker.Items[i])
                {
                    picker.SelectedIndex = i;
                    break;
                }
            }
        }

        Picker MakePicker()
        {
            Picker performance = new Picker();
            

            foreach (ItemCategoryData ic in itemCategoryData)
            {
                if (ic.CategoryType == 3)
                {
                    performance.Items.Add(ic.ItemBody);
                }
            }


            for(int i=0; i<performance.Items.Count; ++i)
            {
                if ("Needs Grading" == performance.Items[i].ToString())
                {
                    performance.SelectedIndex = i;
                    break;
                }
                    
            }

            return performance;
        }

        Grid MakeSign()
        {
            Grid Sign = new Grid();
            Sign.Padding = new Thickness(10, 25);

            Sign.Children.Add(new Label { Text = "Supevisor Sign / Date:" }, 0, 0);
            Sign.Children.Add(new Entry { Placeholder = "Sign Here(to be implemented" }, 1, 0);

            Sign.Children.Add(new Label { Text = "Supervisee Sign / Date:" }, 0, 2);
            Sign.Children.Add(new Entry { Placeholder = "Sign Here(to be implemented" }, 1, 2);

            return Sign;
        }


 
    }
}