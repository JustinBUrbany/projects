﻿using DataContainers.Forms.FormFields;
using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace CertiTracker.Pages.Forms
{
    public partial class BlankForm
    {
        public override void BuildPage()
        {
            if (errorLabel != null)
            {
                StackLayout pagelayout = new StackLayout();
                pagelayout.Children.Add(errorLabel);
                ScrollView pagescroll = new ScrollView
                {

                    Content = pagelayout
                };

                Children.Add(new ContentPage() { Content = pagescroll });
            }
            else
            {
                if(m_formId == null)
                {
                    BuildBlankPage();
                }
                else
                {
                    BuildFilledPage();
                }
            }


            Children.Remove(activityIndicator);
        }

        void BuildBlankPage()
        {
            this.Title = "Form";
            this.Padding = new Thickness(17.5, 15, 17.5, 0);
            BuildFormTypePicker();
            BuildExpereinceTypePicker();

            Label Comments = new Label()
            {
                Text = "Comments"
            };

            m_comments = new Entry()
            {
                Placeholder = "Comments go here:",
                PlaceholderColor = Color.LightGray
            };
            BuildSave();
            BuildSubmit();


            m_headerPage = new ContentPage()
            {
                Content = new ScrollView()
                {
                    Content = new StackLayout()
                    {
                        Children =
                            {
                                m_Type,
                                m_TypeofExperience,
                                MakeHeader(),
                                Comments,
                                m_comments,
                                MakeSign(),
                                m_Save,
                                m_Submit
                            }
                    }

                },
                Title = "Header"
            };
            Children.Add(m_headerPage);

            m_behaviorActivitiesPage = new ContentPage()
            {
                Content = new ScrollView()
                {
                    Content = MakeBehaviorActivities()
                },
                Title = "Behavior Activities"
            };
            Children.Add(m_behaviorActivitiesPage);

            m_characteristcsofSupervisionPage = new ContentPage()
            {
                Content = new ScrollView()
                {
                    Content = MakeCharacteristcsofSupervisionConducted()
                },
                Title = "Supervision Conducted"
            };
            Children.Add(m_characteristcsofSupervisionPage);

            m_skillPage = new ContentPage()
            {
                Content = new ScrollView()
                {
                    Content = MakeSkills()
                },
                Title = "Skills"
            };
            Children.Add(m_skillPage);

            m_competencies = MakeCompetencies();
            Children.Add(m_competencies);
        }

        void BuildFilledPage()
        {
            this.Title = "Form";
            this.Padding = new Thickness(17.5, 15, 17.5, 0);
            BuildFormTypePicker();
            if (m_form.FormType.ItemTitle == "Individual Form") //Set the Type of the Form
            {
                m_Type.SelectedIndex = 0;
            }
            else
            {
                m_Type.SelectedIndex = 1;
            }
            BuildExpereinceTypePicker();

            //TODO Add the Type of Experience to DataBase

            Label Comments = new Label()
            {
                Text = "Comments"
            };

            m_comments = new Entry() //Set the comments
            {
                Text = m_form.Comments
            };

            BuildSave();
            BuildSubmit();

            m_startdate.Date = m_form.StartDate.Date;
            m_endDate.Date = m_form.EndDate.Date;

            m_headerPage = new ContentPage()
            {
                Content = new ScrollView()
                {
                    Content = new StackLayout()
                    {
                        Children =
                            {
                                m_Type,
                                m_TypeofExperience,
                                MakeHeader(),
                                Comments,
                                m_comments,
                                MakeSign(),
                                m_Save,
                                m_Submit
                            }
                    }

                },
                Title = "Header"
            };
            Children.Add(m_headerPage);

            m_behaviorActivitiesPage = new ContentPage()
            {
                Content = new ScrollView()
                {
                    Content = MakeBehaviorActivitiesFilled()
                },
                Title = "Behavior Activities"
            };
            Children.Add(m_behaviorActivitiesPage);

            m_characteristcsofSupervisionPage = new ContentPage()
            {
                Content = new ScrollView()
                {
                    Content = MakeCharacteristcsofSupervisionConductedFilled()
                },
                Title = "Supervision Conducted"
            };
            Children.Add(m_characteristcsofSupervisionPage);


            m_skillPage = new ContentPage()
            {
                Content = new ScrollView()
                {
                    Content = MakeSkillsFilled()
                },
                Title = "Skills"
            };
            Children.Add(m_skillPage);
            m_competencies = MakeCompetenciesFilled();
            Children.Add(m_competencies);
            
        }
        void BuildFormTypePicker()
        {
            m_Type.Title = "Type of Form";
            m_Type.Items.Add("Individual Form");
            m_Type.Items.Add("Group Form");
            m_Type.SelectedIndex = 0;
            m_Type.SelectedIndexChanged += TypeOfFormChanged;
        }
        void BuildExpereinceTypePicker()
        {
            m_TypeofExperience.Title = "Type of Experience";
            m_TypeofExperience.Items.Add("Supervised Independent Fieldwork");
            m_TypeofExperience.Items.Add("Practicum");
            m_TypeofExperience.Items.Add("Intesive Practicum");
        }

        void BuildSave()
        {
            m_Save.Text = "Save";
            m_Save.TextColor = Color.White;
            m_Save.BackgroundColor = Color.FromRgb(0, 160, 255);
            m_Save.Clicked += OnSaveClicked;
        }
        void BuildSubmit()
        {
            m_Submit.Text = "Submit";
            m_Submit.TextColor = Color.White;
            m_Submit.BackgroundColor = Color.FromRgb(0, 160, 255);
            m_Submit.Clicked += OnSaveClicked;
        }

        Entry GetHours(List<ExperienceHours> ex, int index)
        {
            if (ex[index] != null)
            {
                return MakeEntryFilled(ex[index].GetDuration().Hours.ToString());
            }

            return MakeEntryFilled("0");
        }

    }
}
