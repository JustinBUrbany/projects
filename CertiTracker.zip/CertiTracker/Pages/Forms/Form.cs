﻿/************************************************************ 
 * Author: Carl Lowther, Justin urbany 
 * Last edited: January 18, 2018 
 *  
 *  
 * This class is used to display all the information for an 
 * Individual form. 
 *  
 * Parameters: Takes a  
 *  
 ************************************************************/
using System;
using CertiTracker.Utility;
using DataContainers.Forms;
using DataContainers.Forms.FormFields;
using DataContainers.Relationships;
using Xamarin.Forms;
using System.Collections.Generic;
using System.Threading.Tasks;
using CertiTracker.Pages;
using DataContainers;

namespace CertiTracker
{
    public class Form : CertiTrackerTabbedPage
    {

        Label m_Comments = new Label() { Text = "GetComments" };
        CompleteForm m_form;
        BaseRelationship m_relationship;
        TimeSpan m_hoursSupervised;
        Button m_sendtoEmail = new Button() { Text = "Send to Email", TextColor = Color.White, BackgroundColor = Color.FromRgb(0, 160, 255) };

        List<FormCharacteristic> m_formCharacteristics;
        List<FormCompetency> m_formCompetency;
        List<FormEvalField> m_formEvalField;

        bool m_groupform = false;

        string m_formid = null;
        private List<ItemCategoryData> m_itemCategoryData;

        public Form(string formid)
        {
            this.Padding = new Thickness(17.5, 15, 0, 0);
			m_formid = formid;

            StackLayout pagelayout = new StackLayout();
            pagelayout.Children.Add(new ActivityIndicator() { IsRunning = true, Color = Color.FromRgb(0, 160, 255) });
            ScrollView pagescroll = new ScrollView
            {
                Content = pagelayout
            };
            Children.Add(new ContentPage() { Content = pagescroll });
             
            Task.Run(() => GetPageData());
        }

        public override void GetPageData()
        {
            try
            {
                m_form = GetData.getData<CompleteForm>("/Forms/Get1Form/" + m_formid);
                m_itemCategoryData = GetData.getData<List<ItemCategoryData>>("/Forms/CompList");
				m_relationship = GetData.getData<BaseRelationship>("/GetRelationship/RelationshipID/" + m_form.RelationshipID.ToString());
            }
            catch (CertiTrackerException e)
            {
                errorLabel = new Label() { Text = e.Message };
            }

            Action action = BuildPage;
            Device.BeginInvokeOnMainThread(action);
        }

        public override void BuildPage()
        {
            if (errorLabel != null)
            {
                StackLayout pagelayout = new StackLayout();
                pagelayout.Children.Add(errorLabel);
                ScrollView pagescroll = new ScrollView
                {
                    Content = pagelayout
                };

                Children.Add(new ContentPage() { Content = pagescroll });
            }
            else
            {
                this.Title = "Form: " + m_form.StartDate.ToString("MM-dd-yyyy") + " to: " + m_form.EndDate.ToString("MM-dd-yyyy");

                m_hoursSupervised = m_form.GetDuration();
                int fields = m_form.SupervisionTimes.Count;

                m_formCharacteristics = m_form.FormCharacteristics;
                m_formCompetency = m_form.FormCompetencies;
                m_formEvalField = m_form.FormEvalFields;
                m_Comments.Text = m_form.Comments;

                if (m_form.FormType != null)
                {
                    if (m_form.FormType.CategoryItemID.ToString() == "158") //158 means its an individual form
                    {
                        m_groupform = false;
                    }
                    else
                    {
                        m_groupform = true;
                    }
                }
                CreateTabs();
            }

        }

        void CreateTabs()
        {
            Label Comments = new Label() { Text = "Comments:" };

            ContentPage headerPage = new ContentPage()
            {
                Content = new ScrollView()
                {
                    Content = new StackLayout()
                    {
                        Children =
                        {
                            MakeHeader(),
                            new Frame{ Content=Comments },
                            m_Comments,
                            GetSignatures(),
                            m_sendtoEmail
                        }
                    }

                },
                Title = "Header"
            };
            Children.Add(headerPage);

            ContentPage behaviorActivitiesPage = new ContentPage()
            {
                Content = new ScrollView()
                {
                    Content = MakeBehaviorActivities()
                },
                Title = "Behavior Activities"
            };
            Children.Add(behaviorActivitiesPage);

            ContentPage characteristcsofSupervisionPage = new ContentPage()
            {
                Content = new ScrollView()
                {
                    Content = MakeCharacteristcsofSupervisionConducted(),
                    Padding = new Thickness(5,0,10,0)
                },
                Title = "Supervision Conducted"
            };
            Children.Add(characteristcsofSupervisionPage);

            ContentPage skillPage = new ContentPage()
            {
                Content = new ScrollView()
                {
                    Content = MakeSkills()
                },
                Title = "Skills"
            };
            Children.Add(skillPage);


            ContentPage CompetencyPage = new ContentPage()
            {
                Content = new ScrollView()
                {
                    Content = MakeCompetencies()
                },
                Title = "Competencies"
            };
            Children.Add(CompetencyPage);

        }

        public Grid MakeHeader()
        {
            Grid header = new Grid();

            header.Children.Add(new Frame { Content = MakeLabel("Supervisee:"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 0);
            header.Children.Add(MakeLabel(m_relationship.SuperviseeName), 1, 0);

            header.Children.Add(new Frame { Content = MakeLabel("Supervisor:"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 1);
            header.Children.Add(MakeLabel(m_relationship.SupervisorName), 1, 1);

            //header.Children.Add(new Frame { Content = MakeLabel("Form Dates:"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 2);
            //header.Children.Add(MakeLabel(m_form.StartDate.ToString("MM-dd-yyyy") + " to: " + m_form.EndDate.ToString("MM-dd-yyyy")), 1, 2);
            header.Children.Add(new Frame { Content = MakeLabel("Start Date:"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 2);
            header.Children.Add(MakeLabel(m_form.StartDate.ToString("MM-dd-yyyy")), 1, 2);

            header.Children.Add(new Frame { Content = MakeLabel("End Date:"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 3);
            header.Children.Add(MakeLabel(m_form.EndDate.ToString("MM-dd-yyyy")), 1, 3);

            //header.Children.Add(new Frame { Content = MakeLabel("Individual Hours:"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 4);
            //header.Children.Add(MakeLabel(m_hoursSupervised.ToString()), 1, 4);


            return header;
        }

        Grid GetSignatures()
        {
            Grid Sign = new Grid();
            Sign.Padding = new Thickness(10, 25);

            Sign.Children.Add(new Label { Text = "Supevisor Sign / Date:" }, 0, 0);
            Sign.Children.Add(new Entry { Placeholder = "Sign Here(to be implemented" }, 1, 0);

            Sign.Children.Add(new Label { Text = "Supervisee Sign / Date:" }, 0, 2);
            Sign.Children.Add(new Entry { Placeholder = "Sign Here(to be implemented" }, 1, 2);

            return Sign;
        }
        Grid MakeBehaviorActivities()
        {
            Grid BehaviorActivities = new Grid();
            BehaviorActivities.Padding = new Thickness(0, 30);

            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A. Total number of individual experience hours accumulated"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 0);
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A1. Direct implementation\nof theraputic programming"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 1);
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A2. Conducting assements\nrelated to behavioral intervention"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 2);
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A3.Designing and monitoring skill acquistion / behavior reduction prgrams"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 3);
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A4. Overseeing the implementation of behavior-analytic programs by others: "), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 4);
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A5. Training, designing behavioral systems, or performance management"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 5);
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("A6. Other activities such as attending planning meetings regarding the behavior analytic"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 6);
            //BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("program, reviewing relevant literature, and talking to individuals about a program"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 12);
            BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("B. Number of individual supervision hours accumulated\n(number of individual supervision hours)"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 7);

            if (m_groupform == false)
            {
                BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("C.Total experience hours accumulated this period"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 8);
                BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("What percentage of hours were spent in DIRECT intervention?"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 9);
            }
            else
            {
                BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("C.Number of group supervision hours accumulated"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 8);
                BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("D.Total experience hours accumulated this period"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 9);
                BehaviorActivities.Children.Add(new Frame { Content = MakeLabel("What percentage of hours were spent in DIRECT intervention?"), BackgroundColor = Color.FromRgb(0, 160, 255) }, 0, 10);
            }


            Label A = GetHours(m_form.ExpHours, 0);//MakeLabel(m_form.ExpHours[0].GetDuration().ToString() + " hours");           
            Label A1 = GetHours(m_form.ExpHours, 1);
            Label A2 = GetHours(m_form.ExpHours, 2);
			Label A3 = GetHours(m_form.ExpHours, 3);
            Label A4 = GetHours(m_form.ExpHours, 4);
            Label A5 = GetHours(m_form.ExpHours, 5);
            Label A6 = GetHours(m_form.ExpHours, 6);
            Label B = GetHours(m_form.ExpHours, 7);
            Label C = MakeLabel(m_form.GetGroupHours().ToString());
            Label D = MakeLabel(m_form.GetDuration().Hours.ToString());

            double calculation = (m_form.ExpHours[1].GetDuration().TotalHours / m_form.GetDuration().TotalHours) * 100;
            Label E = MakeLabel(calculation.ToString("F") + "%");

            BehaviorActivities.Children.Add(A, 1, 0);
            BehaviorActivities.Children.Add(A1, 1, 1);
            BehaviorActivities.Children.Add(A2, 1, 2);
            BehaviorActivities.Children.Add(A3, 1, 3);
            BehaviorActivities.Children.Add(A4, 1, 4);
            BehaviorActivities.Children.Add(A5, 1, 5);
            BehaviorActivities.Children.Add(A6, 1, 6);
            BehaviorActivities.Children.Add(B, 1, 7);

            if (m_groupform == false)
            {
                BehaviorActivities.Children.Add(D, 1, 8);
                BehaviorActivities.Children.Add(E, 1, 9);
            }
            else
            {
                BehaviorActivities.Children.Add(C, 1, 8);
                BehaviorActivities.Children.Add(D, 1, 9);
                BehaviorActivities.Children.Add(E, 1, 10);
            }

            return BehaviorActivities;
        }

        Grid MakeCharacteristcsofSupervisionConducted()
        {
            Grid characteristics = new Grid();
            characteristics.Padding = new Thickness(0,20);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Characteristics" } }, 0, 0);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Check all that apply" } }, 1, 0);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "BACB Task List Covered:" } }, 0, 1);


            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Client privacy protected" } }, 0, 2);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Supervisory discussion and feedback" } }, 0, 3);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Specific client(s) discussed" } }, 0, 4);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Observation of supervisee video" } }, 0, 5);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Observation of supervisee situ" } }, 0, 6);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "Readings" } }, 0, 7);

            characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            characteristics.Children.Add(new Frame { Content = new Label { Text = "List Readings" } }, 0, 8);

            int b = 0;
            int i = 0;
            Switch BACB = new Switch() { IsEnabled = true, IsToggled = false };
            characteristics.Children.Add(BACB, 1, 1);

            Switch ClientPrivacy = new Switch() { IsEnabled = true, IsToggled = false };
            characteristics.Children.Add(ClientPrivacy, 1, 2);

            Switch Supervisorydiscussion = new Switch() { IsEnabled = true, IsToggled = false };
            characteristics.Children.Add(Supervisorydiscussion, 1, 3);

            Switch Specificclient = new Switch() { IsEnabled = true, IsToggled = false };
            characteristics.Children.Add(Specificclient, 1, 4);

            Switch ObservationofSuperviseeVideo = new Switch() { IsEnabled = true, IsToggled = false };
            characteristics.Children.Add(ObservationofSuperviseeVideo, 1, 5);

            Switch ObservationofSuperviseeSitu = new Switch() { IsEnabled = true, IsToggled = false };
            characteristics.Children.Add(ObservationofSuperviseeSitu, 1, 6);

            Switch Reading = new Switch() { IsEnabled = true, IsToggled = false };
            characteristics.Children.Add(Reading, 1, 7);

            while (m_formCharacteristics.Count > i)
            {
                b = m_formCharacteristics[i].Activity.CategoryItemID;
                switch (b)
                {
                    case (116)://BACB Task List Covered
                        BACB.IsToggled = true;
                       // characteristics.Children.Add(new Label { Text = m_formCharacteristics[i].ActivityText }, 1, 2);
                        break;
                    case (117): //Client Privacy Protected
                        ClientPrivacy.IsToggled = true;
                        break;
                    case (118): //Supervisory discussion and feedback
                        Supervisorydiscussion.IsToggled = true;
                        break;
                    case (119): //Specific client(s) discussed
                        Specificclient.IsToggled = true;
                        break;
                    case (120): //Observation of supervisee(Video)
                        ObservationofSuperviseeVideo.IsToggled = true;
                        break;
                    case (121): //Observation of supervisee (in Situ)
                        ObservationofSuperviseeSitu.IsToggled = true;
                        break;
                    case (122): //Readings
                        Reading.IsToggled = true;
                        characteristics.Children.Add(new Label { Text = m_formCharacteristics[i].ActivityText }, 1, 8);
                        break;
                    default:
                        break;
                }
                ++i;
            }

            if (m_form.SupervisionTimes.Count > 0)
            {
                StackLayout ListViewOfsupervionTimes = new StackLayout();

                foreach (SupervisionTime s in m_form.SupervisionTimes)
                {
                    ListViewOfsupervionTimes.Children.Add(new Label() { Text = s.Date.ToString("MM - dd - yyyy") + " " + s.Duration/TimeSpan.TicksPerHour + " hour(s) supervised" });
                }

                characteristics.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                characteristics.Children.Add(new Frame { Content = ListViewOfsupervionTimes }, 0, 2, 10, 11);
            }

            return characteristics;
        }


        Label MakeLabel(string Header, string content)
        {
            Label ret = new Label();

            ret.Text = Header + content;
            ret.LineBreakMode = LineBreakMode.WordWrap;

            return ret;
        }

        Label MakeLabel(string Header, FontAttributes fontAttributes = FontAttributes.None)
        {
            Label ret = new Label();
            ret.Text = Header;
            ret.LineBreakMode = LineBreakMode.WordWrap;
            //ret.HorizontalOptions = LayoutOptions.Center;
            ret.FontAttributes = fontAttributes;
            return ret;
        }

        Grid MakeSkills()
        {
            Grid skill = new Grid();

            skill.Children.Add(new Label { Text = "Arrives on time for supervision" }, 0, 0);
            if (m_groupform == false)
            {
                skill.Children.Add(new Label { Text = "Demonstrates Appropriate interactions with clients/consumers" }, 0, 1);
                skill.Children.Add(new Label { Text = "Demonstrates appropriate interactoins with other service providers" }, 0, 2);
                skill.Children.Add(new Label { Text = "Maintains appropriate interactions with co-workers" }, 0, 3);
            }
            else
            {
                skill.Children.Add(new Label { Text = "Demonstrates effective time management skills" }, 0, 1);
                skill.Children.Add(new Label { Text = "Demonstrates approrpriate leadership skills" }, 0, 2);
                skill.Children.Add(new Label { Text = "Maintains appropriate interactions with group members" }, 0, 3);
            }
            skill.Children.Add(new Label { Text = "Intiates professional self-improvement as needed" }, 0, 4);
            skill.Children.Add(new Label { Text = "Accepts supervisory feedback appropriately" }, 0, 5);
            skill.Children.Add(new Label { Text = "Seeks supervision appropriately" }, 0, 6);
            skill.Children.Add(new Label { Text = "Demonstrates timely submission of reports or projects" }, 0, 7);
            skill.Children.Add(new Label { Text = "Demonstrates effective written communication" }, 0, 8);
            skill.Children.Add(new Label { Text = "Demonstrates effective oral communication" }, 0, 9);
            skill.Children.Add(new Label { Text = "Demonstrates acquisition of target behavior-analytic skills" }, 0, 10);
            skill.Children.Add(new Label { Text = "Self-detects personal and professional limitations" }, 0, 11);
            skill.Children.Add(new Label { Text = "Overall evaluation of supervisee performance during this period" }, 0, 12);

            return skill;
        }

        StackLayout MakeCompetencies()
        {
            StackLayout competencies = new StackLayout();
            foreach(FormCompetency f in m_form.FormCompetencies)
            {
                competencies.Children.Add(new Label(){Text = GetCompetency(f.CompetencyID) });
            }

            return competencies;
        }

        string GetCompetency(int competencyId)
        {
            foreach (ItemCategoryData ic in m_itemCategoryData)
            {
                if (ic.CategoryType == 0 && ic.CategoryItemID == competencyId)
                {
                    return ic.ItemTitle + " " + ic.ItemBody;
                }
            }
            return "error with id: " + competencyId;
        }

        Label GetHours(List<ExperienceHours> ex, int index)
        {
            if (ex[index] != null)
            {
                return MakeLabel(ex[index].GetDuration().ToString() + " hours");
            }

            return MakeLabel("0 hours");
        }

        Label getGrade(int itemid)
        {
            string grade;
            if (itemid == 136)
            {
                grade = "Exemplary";
            }
            else if (itemid == 137)
            {
                grade = "Satifactory";
            }
            else if (itemid == 138)
            {
                grade = "Needs Improvement";
            }
            else if (itemid == 139)
            {
                grade = "Unsatisfactory";
            }
            else if(itemid==140)
            {
                grade = "Not Applicable";
            }
            else
            {
                grade = "Needs Grading";
            }
            return new Label() { Text = grade };
        }
    }
}
