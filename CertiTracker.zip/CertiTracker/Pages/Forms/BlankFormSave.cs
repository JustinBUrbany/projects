﻿using System;
using System.Collections.Generic;
using DataContainers;
using DataContainers.Forms;
using Xamarin.Forms;
using CertiTracker.Utility;
using System.Net;
using DataContainers.Forms.FormFields;

namespace CertiTracker.Pages.Forms
{
    public partial class BlankForm
    {
        async void OnSaveClicked(object sender, EventArgs e)
        {
            //await DisplayAlert("Alert", "Your Form has been saved", "OK");
            //Validation
            SaveForm(sender, e);
        }

        async void SaveForm(object sender, EventArgs e)
        {

            CompleteForm completeForm = new CompleteForm();
            if(m_form != null)
            {
                completeForm.FormID = m_form.FormID;
            }
            completeForm.Comments = m_comments.Text;

            //TODO Crashes on null duration
            if(m_hours.Text != null)
            {
				completeForm.Duration = long.Parse(m_hours.Text);
            }

            completeForm.EndDate = m_endDate.Date;
            completeForm.StartDate = m_startdate.Date;
            
            completeForm.RelationshipID = m_relationshipid;

            completeForm.SupervisionTimes = m_supervisionTimes;

            //TODO WTF is in a FormCompetency Date Item Title Item Body ItemCategoryData[4] has done with coaching etc
            //completeForm.FormCompetencies = ListOfAppliedCompetencies[0];
            completeForm.FormCompetencies = new List<FormCompetency>();
            foreach(FormCompetency c in ListOfAppliedCompetencies)
            {
                completeForm.FormCompetencies.Add(c);
            }

            ItemCategoryData grades = new ItemCategoryData();
            grades.CategoryType = 3;
            grades.CategoryItemID = GetItemID(m_Overall);
            if (grades.CategoryItemID != -1)
            {
                completeForm.FormGrade = grades;
            }

            ItemCategoryData formtype = new ItemCategoryData();

            formtype.CategoryType = 8; //Category Type for from type is 8
            if (m_Type.SelectedIndex == 0) //If an individual form then category Item Id is 158
            {
                formtype.CategoryItemID = 158;//TODO change from being hard coded+
                completeForm.GroupHours = -1;
            }
            else //Else it is a group form and the item id is 159
            {
                formtype.CategoryItemID = 159;
                completeForm.GroupHours = TimeSpan.FromHours(double.Parse(m_C.Text)).Ticks;

            }

            completeForm.FormType = formtype;

            List<ExperienceHours> formhours = new List<ExperienceHours>();


            int id = GetHoursID("A");
			formhours.Add(WriteHours(id, m_A.Text));
            //formhours.Add(new ExperienceHours(new ItemCategoryData(id), TimeSpan.FromHours(double.Parse(m_A.Text))));

            id = GetHoursID("1");
            formhours.Add(WriteHours(id, m_A1.Text));

            id = GetHoursID("2");
            formhours.Add(WriteHours(id, m_A2.Text));

            id = GetHoursID("3");
            formhours.Add(WriteHours(id, m_A3.Text));

            id = GetHoursID("4");
            formhours.Add(WriteHours(id, m_A4.Text));

            id = GetHoursID("5");
            formhours.Add(WriteHours(id, m_A5.Text));

            id = GetHoursID("6");
            formhours.Add(WriteHours(id, m_A6.Text));

            id = GetHoursID("B");
            formhours.Add(WriteHours(id, m_B.Text));

            completeForm.ExpHours = formhours;

            //TODO set this from UI
            completeForm.ValidFlag = null;

            List<FormEvalField> allgrades = new List<FormEvalField>();


            FormEvalField somegrade  = new FormEvalField(); // TODO remove hard coded values for characteristics
            for (int i = 0; i < 13; ++i)
            {
                somegrade.EvalCategory.CategoryType = 2;
                //somegrade.EvalCategory.CategoryItemID = i + 123;
                foreach(ItemCategoryData ic in itemCategoryData)
                {
                    if(m_skillstring[i] == ic.ItemTitle)
                    {
                        somegrade.EvalCategory.CategoryItemID = ic.CategoryItemID;
                    }
                }
                somegrade.Grade.CategoryType = 3;
                somegrade.Grade.CategoryItemID = GetItemID(m_evalgrades[i]);
                
                allgrades.Add(somegrade);
                somegrade = new FormEvalField();
            }
            completeForm.FormEvalFields = allgrades;

            List<FormCharacteristic> charateristics = new List<FormCharacteristic>();

            FormCharacteristic characteristic = new FormCharacteristic(); //TODO fix the hard coded values

            for (int i = 0; i < 7; ++i)
            {
                characteristic.Activity.CategoryType = 1;
                if (m_characteristics[i].IsToggled == true)
                {
                    characteristic.Activity.CategoryItemID = i + 116; // Item CategoryId is 116 offset in database
                    charateristics.Add(characteristic);
                    characteristic = new FormCharacteristic();
                }
            }


            completeForm.FormCharacteristics = charateristics;
            string urlvar = "Forms/Create";
            if(m_form != null)
            {
                urlvar = "Forms/Update";
            }
            HttpStatusCode response = PostData.postData(completeForm, urlvar).Result.StatusCode;
            if (response == System.Net.HttpStatusCode.Created)
            {
                await DisplayAlert("Alert", "Form Created", "OK");
            }
            else if (response == System.Net.HttpStatusCode.BadRequest)
            {
                await DisplayAlert("Alert", "Email is alread", "OK");
            }
            else
            {
                await DisplayAlert("Alert", "Coudn't create Form.", "OK");
            }
        }
        int GetItemID(Picker skill)
        {
            int gradeID = -1;

            foreach(ItemCategoryData ic in itemCategoryData)
            {
                if (ic.CategoryType == 3 && ic.ItemBody == skill.SelectedItem.ToString())
                {
                    gradeID = ic.CategoryItemID;
                    break;
                }
            }
            return gradeID;
        }
        int GetHoursID(string item)
        {
            int hourID = -1;
            foreach(ItemCategoryData ic in itemCategoryData)
            {
                if (ic.CategoryType == 9 && ic.ItemTitle == item)
                {
                    hourID = ic.CategoryItemID;
                    break;
                }
            }

            return hourID;
        }
        private bool validateform()
        {
            bool isvalid = true;

            return isvalid;
        }

        ExperienceHours WriteHours(int id, string text)
        {
            if (text != null)
            {
				return new ExperienceHours(new ItemCategoryData(id), TimeSpan.FromHours(double.Parse(text)));
            }

            return new ExperienceHours(new ItemCategoryData(id), TimeSpan.FromHours(double.Parse("0")));
        }
    }
}
