﻿/************************************************************ 
* Author: Carl Lowther
* Last edited: January 18, 2018
*
*
* This class is used to display a list buttons that contain
* the form dates and supervisor name so that they can search
* for a specific form and select it from the list
*
*
* Parameters: (Takes in a List of forms or searches for forms)
*
*
*
*************************************************************/
using System;
using System.Collections.Generic;
using Xamarin.Forms;
using CertiTracker.Utility;
using DataContainers.Forms;
using System.Threading.Tasks;
using CertiTracker.Pages;
using DataContainers.Users;
using DataContainers.Relationships;
using CertiTracker.Pages.Forms;

namespace CertiTracker
{
    public class FormsPage : CertiTrackerTabbedPage
    {		
		//********* Predeclaring Variable
        List<BaseForm> forms = new List<BaseForm>();

        ContentPage m_ActiveForms;
        ContentPage m_ValidForms;
        ContentPage m_InVaildForms;

        string m_userid = null;
        public ContentPage activityIndicator;

        public FormsPage(string userid)
        {
            m_userid = userid;

            //********* Page Set Up
            m_userid = userid;
            //this.Padding = new Thickness(17.5, 15, 17.5, 0);
            this.Title = "Forms Page";


            AddActitivtyIndicator();
            Task.Run(() => GetPageData());
            //scrolllayout.Content = pagelayout;
            //Content = scrolllayout;
        }

        public void AddActitivtyIndicator()
        {
            StackLayout stackLayout = new StackLayout()
            {
                VerticalOptions = LayoutOptions.CenterAndExpand
            };
            stackLayout.Children.Add(new ActivityIndicator() { IsRunning = true, Color = Color.FromRgb(0, 160, 255) });

            activityIndicator = new ContentPage() { Content = stackLayout };
            Children.Add(activityIndicator);
        }

		public override void GetPageData()
		{
			try
			{
				forms = GetData.getData<List<BaseForm>>("/Forms/GetForms/" + m_userid);
				
				forms.Reverse();
				//forms = GetData.getData<List<BaseForm>>("/GetForm/Supervisees/All/" + m_userid);
			}
			catch (CertiTrackerException e)
			{
				errorLabel = new Label() { Text = e.Message };
			}
			
			Action action = BuildPage;
			Device.BeginInvokeOnMainThread(action);
			
		}

        override public void BuildPage()
        {

            if (errorLabel == null)
            {
                m_ActiveForms = new ContentPage()
                {
                    Content = BuildActiveForms(),
                    Title = "Active Forms"
                };
                m_ActiveForms.Padding = new Thickness(20, 20, 20, 0);
                Children.Add(m_ActiveForms);

                m_ValidForms = new ContentPage()
                {
                    Content = BuildVaildForms(),
                    Title = "Vaild Forms"
                };
                m_ValidForms.Padding = new Thickness(20, 20, 20, 0);
                Children.Add(m_ValidForms);

                m_InVaildForms = new ContentPage()
                {
                    Content = BuildInVaildForms(),
                    Title = "InVaild Forms"
                };
                m_InVaildForms.Padding = new Thickness(20, 20, 20, 0);
                Children.Add(m_InVaildForms);

            }
            else
            {
                ContentPage errorPage = new ContentPage()
                {
                    Content = errorLabel
                };
                Children.Add(errorPage);
            }




            Children.Remove(activityIndicator);
        }

        private View BuildInVaildForms()
        {
            StackLayout InVaildForms = new StackLayout();

            List<Button> buttons = new List<Button>();

            foreach (BaseForm b in forms)
            {
                if (b.ValidFlag == false)
                {
                    buttons.Add(new Button()
                    {
                        Text = b.StartDate.Date.ToString("MM-dd-yyyy") + " to: " + b.EndDate.Date.ToString("MM-dd-yyyy"),
                        TextColor = Color.White,
                        BackgroundColor = Color.FromRgb(0, 160, 255),
                        StyleId = b.FormID.ToString()

                    });

                    buttons[buttons.Count - 1].Clicked += shFormClicked;
                    InVaildForms.Children.Add(buttons[buttons.Count - 1]);
                }
            }


            return new ScrollView() { Content = InVaildForms };
        }

        ScrollView BuildVaildForms()
        {
            StackLayout VaildForms = new StackLayout();

            List<Button> buttons = new List<Button>();

            foreach (BaseForm b in forms)
            {
                if (b.ValidFlag == true)
                {
                    buttons.Add(new Button()
                    {
                        Text = b.StartDate.Date.ToString("MM-dd-yyyy") + " to: " + b.EndDate.Date.ToString("MM-dd-yyyy"),
                        TextColor = Color.White,
                        BackgroundColor = Color.FromRgb(0, 160, 255),
                        StyleId = b.FormID.ToString()

                    });

                    buttons[buttons.Count - 1].Clicked += shFormClicked;
                    VaildForms.Children.Add(buttons[buttons.Count - 1]);
                }
            }


            return new ScrollView() { Content = VaildForms };
        }

        ScrollView BuildActiveForms()
        {
            StackLayout activeForms = new StackLayout();

            List<Button> buttons = new List<Button>();

            Button m_newform = new Button();
            m_newform.Text = "Start New Form";
            m_newform.BackgroundColor = Color.FromRgb(0, 160, 255);
            m_newform.TextColor = Color.White;
            m_newform.Clicked += NewFormClicked;

            if (!StaticUser.isSupervisor)
                activeForms.Children.Add(m_newform);

            foreach (BaseForm b in forms)
            {
                if(b.ValidFlag == null)
                {
					buttons.Add(new Button()
					{
						Text = b.StartDate.Date.ToString("MM-dd-yyyy") + " to: " + b.EndDate.Date.ToString("MM-dd-yyyy"),
						TextColor = Color.White,
						BackgroundColor = Color.FromRgb(0, 160, 255),
						StyleId = b.FormID.ToString()
						           
					});

                    buttons[buttons.Count - 1].Clicked += shFormClicked;
                    activeForms.Children.Add(buttons[buttons.Count - 1]);
				}
            }

            return new ScrollView(){Content = activeForms};
        }

        async void shFormClicked(object sender, EventArgs e)
        {
            int id = int.Parse((sender as Button).StyleId);

            BaseForm bf = null;

            foreach(BaseForm b in forms)
            {
				if(b.FormID == id)
                {
                    bf = b;
                    break;
                }
            }

            if(bf.ValidFlag != null)
            {
                await Navigation.PushAsync(new Form(id.ToString()));
            }
            else
            {
                await Navigation.PushAsync(new BlankForm(id.ToString()));
            }
        }

        async void NewFormClicked(object sender, EventArgs e)
        {
            List<SupervisorUser> supervisors = null;

            try
            {
                supervisors = GetData.getData <List<SupervisorUser>>("/GetRelationship/User/Supervisors/" + m_userid);
				
                if(supervisors.Count<=0)
				{
					await DisplayAlert("You have no Supervisor", "Please get a supervisor before trying to make a form", "OK");
				}
				else if(supervisors.Count == 1)
				{
                    await Navigation.PushAsync(new BlankForm(m_userid,supervisors[0].UID.ToString(), supervisors[0].SID.ToString()));
				}
				else
				{
					await Navigation.PushAsync(new SelectSupervisor(m_userid));
				}
            }
            catch (CertiTrackerException ex)
            {
                await DisplayAlert("Not connected to the internet", ex.Message, "OK");
                //errorLabel = new Label() { Text = ex.Message };
            }
        }
    }
}
