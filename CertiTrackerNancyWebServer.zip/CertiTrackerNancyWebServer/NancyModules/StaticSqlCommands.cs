﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NancyModules
{
    public static class StaticSqlCommands
    {
        static private string _SQLConnectionString = "Data Source = satou.cset.oit.edu" +
                                                                ";Initial Catalog=" + "certitracker" +
                                                                ";Integrated Security=False" +
                                                                ";User ID=" + "StandardUser" + ";Password=" + "r6avwSDnbMZ9RJyX";

        static public string SQLConnectionString { get { return _SQLConnectionString; } }



        static private string _CMDGetSupervisorsSupervisees = "SELECT Distinct SuperviseeID " +
                                                                " FROM TEST.Relationships AS R " +
                                                                " WHERE SupervisorID = @SupervisorID " +
                                                                " ORDER BY SuperviseeID";


        /*static private string _CMDGetAllSupervisors = "select * from TEST.Supervisors as S" +
                                                        "join TEST.Users as U" +
                                                        "on S.UserID = U.UserID";*/

        static private string _CMDGetUsersSupervisors = "select U.UserID " +
                                                        "from TEST.Relationships as R " +
                                                            "join TEST.Supervisors as S " +
                                                                "on R.SupervisorID = S.SupervisorID " +
                                                            "join TEST.Users as U " +
                                                                "on S.UserID = U.UserID " +
                                                        "where R.SuperviseeID = @UserID " +
                                                        "order by U.UserID";

        static private string _CMDSupervisorUserID = "Select Users.UserID From TEST.Users join TEST.Supervisors on Users.UserID = Supervisors.UserID where SupervisorID = @SupervisorID";

        static private string _CMDGetSupervisorFromUserID = "select * " +
                                                            "from TEST.Users as u " +
                                                             "   join TEST.Supervisors as s " +
                                                             "   on u.UserID = s.UserID " +
                                                            "where s.UserID = @UserID ";

        static private string _CMDGetAllSupervisors = "select u.UserID " +
                                                      "from TEST.Users as u " +
                                                          "join TEST.Supervisors as s " +
                                                              "on u.UserID = s.UserID ";


        static private string _CMDGetSuperviseesForms = @"select FormID
                                                            from TEST.Forms as f
                                                                join TEST.Relationships as r
                                                                on f.RelationshipID = r.RelationshipID
                                                            where r.SuperviseeID = @UserID";

        static private string _CMDGetBasicRelationship = "select * from TEST.Relationships where RelationshipID = @RelationshipID";

        static private string _CMDGetRelationshipBothIDs = "select * from TEST.Relationships where SuperviseeID = @SuperviseeID and SupervisorID = @SupervisorID";


        static public string CMDGetSupervisorsSupervisees { get { return _CMDGetSupervisorsSupervisees; } }
        static public string CMDGetUsersSupervisors { get { return _CMDGetUsersSupervisors; } }
        public static string CMDSupervisorUserID { get => _CMDSupervisorUserID; }
        public static string CMDGetSupervisorFromUserID { get => _CMDGetSupervisorFromUserID; }
        public static string CMDGetAllSupervisors { get => _CMDGetAllSupervisors; }
        static public string CMDGetSuperviseesForms { get { return _CMDGetSuperviseesForms; } }
        static public string CMDGetBasicRelationship { get { return _CMDGetBasicRelationship; } }
        public static string CMDGetRelationshipBothIDs { get { return _CMDGetRelationshipBothIDs; } }


        //static public string CMDGetAllSupervisors { get { return _CMDGetAllSupervisors; } }

        //static public string CMDGetAllSupervisors { get { return _CMDGetAllSupervisors; } }


        private static string _CMDInsertUser = "Insert TEST.Users (FName, LName, Email, Location, Background, AreaOfInterest) " +
                                                "Values (@FName, @LName, @Email, @Location, @Background, @AreaOfInterest) ";
        private static string _CMDInsertSupervisor = 
                                    @"DECLARE @USERID INT 
                                    BEGIN TRY

                                        BEGIN TRAN;
                                            INSERT INTO TEST.Users(FName, LName, Email, AreaOfInterest, Background, Location)
                                            VALUES(@FName, @LName, @Email, @AreaOfInterest, @Background, @Location);

                                            SET @USERID = @@IDENTITY;

	                                        INSERT INTO TEST.Supervisors(UserID, CertificationNumber, DateCertified, DateCompletedSupervision, DistanceSupervision)
                                            VALUES(@USERID, @CertificationNumber, @DateCertified, @DateCompletedSupervision, @DistanceSupervison);
                                        COMMIT TRAN;
                                        END TRY
                                    BEGIN CATCH
                                        ROLLBACK TRAN;
                                    END CATCH";

        private static string _CMDInsertRelationship = "INSERT INTO TEST.Relationships (SuperviseeID, SupervisorID, StartDate, EndDate, Comments, Pending) " +
                                                            " VALUES (@SuperviseeID, @SupervisorID, @StartDate, @EndDate, @Comments, @Pending); ";

        private static string _CMDCheckCurrentRelationships = "select COUNT(RelationshipID) as num " +
                                                                "from TEST.Relationships " +
                                                                "WHERE GETDATE() between StartDate and EndDate " +
                                                                " and supervisorID = @SupervisorID and SuperviseeID = @SuperviseeID ";

        private static string _CMDInsertFormsTable = @"INSERT INTO TEST.Forms (RelationshipID, StartDate, EndDate, FormGrade, Comments, ValidFlag, GroupHours, FormType) 
                                                    Values(@RelationshipID, @StartDate, @EndDate, @FormGrade, @Comments, @ValidFlag, @GroupHours, @FormType); 
                                                    SELECT SCOPE_IDENTITY(); ";

        private static string _CMDInsertFormSupervisonTimes = @"INSERT INTO TEST.FormSupervisionTimes (FormID, SupervisionDate, SupervisionDuration) 
                                                                Values(@FORMID, @SupervisionDate, @SupervisionDuration);";

        private static string _CMDInsertFormEval = @"INSERT INTO TEST.FormEval (FormID, EvalCategoryID, GradeID)  
	                                                Values (@FORMID, @EvalCategoryID, @GradeID);";

        private static string _CMDInsertFormCharacteristics = @"INSERT INTO TEST.FormCharacteristics (FormID, ActivityID, ActivityText) 
	                                                            Values (@FORMID, @ActivityID, @Description);";

        private static string _CMDInsertFormCompetencies = @"INSERT INTO TEST.FormCompetencies (FormID, CompetencyID, EvaluationDate, Duration) 
	                                                        Values (@FORMID, @CompetencyID, @EvaluationDate, @Duration);";

        private static string _CMDInsertFormExperienceHours = @"insert into TEST.FormExperienceHours (FormID, ItemCategoryID, Duration)
		                                                        Values (@FORMID, @ItemCategoryID, @Duration)";

        public static string CMDInsertUser { get => _CMDInsertUser; }
        public static string CMDInsertRelationship { get => _CMDInsertRelationship; }
        public static string CMDCheckCurrentRelationships { get => _CMDCheckCurrentRelationships; }
        public static string CMDInsertSupervisor { get => _CMDInsertSupervisor; }
        public static string CMDInsertFormsTable { get => _CMDInsertFormsTable; }
        public static string CMDInsertFormSupervisonTimes { get => _CMDInsertFormSupervisonTimes; }
        public static string CMDInsertFormEval { get => _CMDInsertFormEval; }
        public static string CMDInsertFormCharacteristics { get => _CMDInsertFormCharacteristics; }
        public static string CMDInsertFormCompetencies { get => _CMDInsertFormCompetencies; }
        public static string CMDInsertFormExperienceHours { get => _CMDInsertFormExperienceHours; }
    }
}
