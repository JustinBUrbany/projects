﻿/*
* Author: Morgan Loring
* Date Created: 1/16/2018
* Log:
*   1/22/2018:
*       Refactored to use Datacontainers - ML
*   1/23/2018:
*       Added and modified modules - ML
*/


using Nancy;
using System;
using System.IO;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NancyModules;
using DataContainers;
using DataContainers.Users;
using RetrievableDataContainers.Users;
using Newtonsoft.Json;
using Nancy.ModelBinding;

namespace NancyModules
{
    public class UserModule : NancyModule
    {
        const int M_EMAIL_ALREADY_EXISTS = 0;

        /*
         * Purpose: 
         *   ctor defines urls related to user data
         * Parameters:
         *   N/A
         * Returns:
         *   N/A
         */
        public UserModule()
        {
            Get["/GetUser/{UserID}"] = GetUserData; //  Parameters - UserID, Return BasicUserData/SupervisorUserData
            Get["/GetSupervisor/{SupervisorID}"] = GetSupervisorData;
            Get["/GetSupervisorsUserID/{SupervisorID}"] = GetSupervisorUserID;
            Get["/GetSupervisor/{UserID}"] = GetSupervisorFromUserID;
            Get["/GetAllSupervisors"] = GetAllSupervisors;
            Post["/PostUser"] = PostUser;   //  Parameters- JSON Object containing data to insert
            Post["/PostSupervisor"] = PostSupervisor;   //  Parameters- JSON Object containing data to insert

            //Get["/textfile"] = CreateTextFile;
            //Get["/textfile2"] = CreateTextFile2;
        }

        private dynamic CreateTextFile(dynamic arg)
        {
            string path = Directory.GetCurrentDirectory();
            path += "/test.txt";
            try
            {
                using (FileStream fs = File.Create(path))
                {
                    Byte[] info = new UTF8Encoding(true).GetBytes("This is a text file");
                    fs.Write(info, 0, info.Length);
                }
                using (StreamReader sr = File.OpenText(path))
                {
                    return sr.ReadLine();
                }
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

        private dynamic CreateTextFile2(dynamic arg)
        {
            string path = @"c:\CertFiles\test.txt";
            string dir = @"c:\CertFiles";

            try
            {
                if (!Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }

                using (FileStream fs = File.Create(path))
                {
                    Byte[] info = new UTF8Encoding(true).GetBytes("This is a text file");
                    fs.Write(info, 0, info.Length);
                }
                using (StreamReader sr = File.OpenText(path))
                {
                    return sr.ReadLine();
                }
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

        /*
         * Purpose:
         *  This function returns a users data found in the Users table of the DB
         * Paramaters:
         *  user id - int
         * Returns:
         *  Returns User data in a container class
         */
        internal dynamic GetUserData(dynamic arg)
        {
            int userID = arg.userID;
            ExpandedUser userData = null;
            bool success = true;
            Response response;
            try
            {
                userData = UserStaticMethods.Fetch(userID, RetrievableDataContainers.RetrievalFlags.Tier2 | RetrievableDataContainers.RetrievalFlags.Tier1);
            }
            catch (Exception ex)
            {
                success = false;
            }

            if(success)
            {
                response = JsonConvert.SerializeObject(userData);
                response.StatusCode = HttpStatusCode.OK;
            }
            else
            {
                response = "Error occured";
                response.StatusCode = HttpStatusCode.InternalServerError;
            }
            return response;
            return userData;
        }
        internal dynamic GetSupervisorData(dynamic arg)
        {
            int userID = arg.SupervisorID;
            SupervisorUser userData;
            userData = UserStaticMethods.Fetch(userID, RetrievableDataContainers.RetrievalFlags.AllTier);
            var response = (Response);
            return userData;
        }

        internal dynamic GetSupervisorUserID(dynamic arg)
        {
            int supervisorID = arg.SupervisorID;
            int result = -1;
            ExpandedUser user = null;

            using (SqlConnection con = new SqlConnection(StaticSqlCommands.SQLConnectionString))
            {
                SqlCommand cmd = new SqlCommand(StaticSqlCommands.CMDSupervisorUserID, con);
                cmd.Parameters.AddWithValue("SupervisorID", supervisorID);
                con.Open();
                using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    if (rd.Read())
                    {
                        int userID = (int)rd["UserID"];
                        user = UserStaticMethods.Fetch(userID, RetrievableDataContainers.RetrievalFlags.Tier2 | RetrievableDataContainers.RetrievalFlags.Tier1);
                        result = 1;
                    }
                    con.Close();
                }
            }
            Response response;
            if (result == 1)
            {
                response = JsonConvert.SerializeObject(user);
                response.StatusCode = HttpStatusCode.OK;
            }
            else
            {
                response = "Error";
                response.StatusCode = HttpStatusCode.InternalServerError;
            }
            return response;
        }

        internal dynamic GetSupervisorFromUserID(dynamic arg)
        {
            Response response = new Nancy.Response();
            int userID = arg.UserID;

            int result = -1;
            ExpandedUser user = null;

            using (SqlConnection con = new SqlConnection(StaticSqlCommands.SQLConnectionString))
            {
                SqlCommand cmd = new SqlCommand(StaticSqlCommands.CMDGetSupervisorFromUserID, con);
                cmd.Parameters.AddWithValue("UserID", userID);
                con.Open();
                using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    if (rd.Read())
                    {
                        user = UserStaticMethods.Fetch(userID, RetrievableDataContainers.RetrievalFlags.AllTier);
                        result = 1;
                    }
                    con.Close();
                }
            }

            if (result == 1)
            {
                response = JsonConvert.SerializeObject(user);
                response.StatusCode = HttpStatusCode.OK;
            }
            else
            {
                response = "Error";
                response.StatusCode = HttpStatusCode.InternalServerError;
            }
            return response;
        }

        internal dynamic GetAllSupervisors(dynamic arg)
        {
            string cmdString = StaticSqlCommands.CMDGetAllSupervisors;
            List<SupervisorUser> userIDs = new List<SupervisorUser>();

            using (SqlConnection con = new SqlConnection(StaticSqlCommands.SQLConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(cmdString, con))
                {
                    con.Open();
                    using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (rd.HasRows)
                        {
                            while (rd.Read())
                            {
                                userIDs.Add(new SupervisorUser((int)rd["UserID"]));
                            }
                        }
                        con.Close();
                    }
                }
            }

            foreach (SupervisorUser i in userIDs)
            {
                UserStaticMethods.Fetch(i, RetrievableDataContainers.RetrievalFlags.Tier1);
            }
            return userIDs;
        }

        private dynamic PostUser(dynamic arg)
        {
            int result = -1;

            var user = this.Bind<ExpandedUser>();

            using (SqlConnection con = new SqlConnection(StaticSqlCommands.SQLConnectionString))
            {
                SqlCommand cmd = new SqlCommand(StaticSqlCommands.CMDInsertUser, con);
                cmd = AddUserData(user, cmd);
                con.Open();
                try
                {
                    result = cmd.ExecuteNonQuery();
                }
                catch (SqlException ex)
                {
                    result = M_EMAIL_ALREADY_EXISTS;
                }
                con.Close();
            }
            Response response;
            if (result == 1)
            {
                response = "User inserted";
                response.StatusCode = HttpStatusCode.Created;
            }
            else if (result == M_EMAIL_ALREADY_EXISTS)
            {
                response = "User already exists";
                response.StatusCode = HttpStatusCode.BadRequest;
            }
            else
            {
                response = "Error";
                response.StatusCode = HttpStatusCode.InternalServerError;
            }
            return response;
        }

        
        private dynamic PostSupervisor(dynamic arg)
        {
            int result = -1;

            var user = this.Bind<SupervisorUser>();

            using (SqlConnection con = new SqlConnection(StaticSqlCommands.SQLConnectionString))
            {
                SqlCommand cmd = new SqlCommand(StaticSqlCommands.CMDInsertSupervisor, con);
                cmd = AddUserData(user, cmd);
                cmd.Parameters.AddWithValue("@CertificationNumber", user.CertificationNumber);
                cmd.Parameters.AddWithValue("@DateCertified", user.DateCertified);
                cmd.Parameters.AddWithValue("@DateCompletedSupervision", user.DateCompletedSupervision);
                cmd.Parameters.AddWithValue("@DistanceSupervison", user.DistanceSupervision);
                con.Open();
                try
                {
                    result = cmd.ExecuteNonQuery();
                }
                catch (SqlException ex)
                {
                    result = M_EMAIL_ALREADY_EXISTS;
                }
                con.Close();
            }
            Response response;
            if (result == 2)
            {
                response = "User inserted";
                response.StatusCode = HttpStatusCode.Created;
            }
            else if (result == M_EMAIL_ALREADY_EXISTS)
            {
                response = "User already exists";
                response.StatusCode = HttpStatusCode.BadRequest;
            }
            else
            {
                response = "Error";
                response.StatusCode = HttpStatusCode.InternalServerError;
            }
            return response;
        }
        private SqlCommand AddUserData(ExpandedUser user, SqlCommand cmd)
        {
            cmd.Parameters.AddWithValue("@FName", user.FName);
            cmd.Parameters.AddWithValue("@LName", user.LName);
            cmd.Parameters.AddWithValue("@Email", user.Email);
            cmd.Parameters.AddWithValue("@AreaOfInterest", user.AreaOfInterest);
            cmd.Parameters.AddWithValue("@Background", user.Background);
            cmd.Parameters.AddWithValue("@Location", user.Location);
            return cmd;
        }

        //private dynamic PostUser(dynamic arg)
        //{
        //    int result = -1;
        //    ExpandedUser user = new ExpandedUser();
        //    user.FName = (string)Request.Form.FName;
        //    user.LName = (string)Request.Form.LName;
        //    user.Email = (string)Request.Form.Email;
        //    user.AreaOfInterest = (string)Request.Form.AreaOfInterest;
        //    user.Background = (string)Request.Form.Background;
        //    user.Location = (string)Request.Form.Location;

        //    using (SqlConnection con = new SqlConnection(StaticSqlCommands.SQLConnectionString))
        //    {
        //        using (SqlCommand cmd = new SqlCommand(StaticSqlCommands.CMDInsertUser, con))
        //        {
        //            cmd.Parameters.AddWithValue("@FName", user.FName);
        //            cmd.Parameters.AddWithValue("@LName", user.LName);
        //            cmd.Parameters.AddWithValue("@Email", user.Email);
        //            cmd.Parameters.AddWithValue("@AreaOfInterest", user.AreaOfInterest);
        //            cmd.Parameters.AddWithValue("@Background", user.Background);
        //            cmd.Parameters.AddWithValue("@Location", user.Location);

        //            con.Open();
        //            try
        //            {
        //                result = cmd.ExecuteNonQuery();
        //            }
        //            catch (SqlException ex)
        //            {
        //                //if (ex.ErrorCode)
        //                result = M_EMAIL_ALREADY_EXISTS;
        //            }
        //            con.Close();
        //        }
        //    }
        //    Response response;
        //    if (result == 1)
        //    {
        //        response = "User inserted";
        //        response.StatusCode = HttpStatusCode.Created;
        //    }
        //    else if (result == M_EMAIL_ALREADY_EXISTS)
        //    {
        //        response = "Email already exists";
        //        response.StatusCode = HttpStatusCode.BadRequest;
        //    }
        //    else
        //    {
        //        response = "Error";
        //        response.StatusCode = HttpStatusCode.InternalServerError;
        //    }
        //    return response;
        //}
    }
}
