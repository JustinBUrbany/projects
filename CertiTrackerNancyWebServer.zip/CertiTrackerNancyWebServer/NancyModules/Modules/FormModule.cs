﻿/*
* Author: Morgan Loring
* Date Created: 1/16/2018
* Log:
*/

using Nancy;
using System;
using NancyModules;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using RetrievableDataContainers.Forms;
using DataContainers.Forms;
using Nancy.ModelBinding;
using DataContainers;
using DataContainers.Forms.FormFields;
using Newtonsoft.Json;
using NancyModuleMethods;

namespace CertiTrackerNancyWebServer
{
    public class FormModule : NancyModule
    {
        public FormModule()
        {
            Get["/Forms/Get1Form/{FormID}"] = GetAForm; // Returns a complete user form
            Get["/Forms/GetForms/{UserID}"] = GetForms; // parameters - UserID, returns start_date, end_date, form_id, supervisor_name, status
            Get["/Forms/FilterForms/{UserID}/{Valid?}"] = ValidFilter;
            Get["/Forms/CompList"] = GetCompetencyList;
            Post["/Forms/Create"] = CreateForm;
            Post["/Forms/Update"] = UpdateForm;
        }

        /*
        private dynamic EmailAllForms(dynamic arg)
        {
            throw new NotImplementedException();
            int userID = arg.userID;
            List<CompleteForm> initForms = GetForms(userID);
            List<CompleteForm> FormsList = new List<CompleteForm>();

        //    foreach(CompleteForm x in FormsList)
        //    {
        //        if (x.ValidFlag == true)
        //        {
        //            FormsList.Add(FormStaticMethods.Fetch(x, RetrievableDataContainers.RetrievalFlags.AllTier));
        //        }
        //    }

        //    if (FormsList.Count > 0)
        //    {
        //        foreach(CompleteForm x in FormsList)
        //        {
        //            FormsToExcel(x, "path");
        //            ExcelToPDF("path");
        //            // Add to list of paths to send
        //            // pass to email method.
        //        }
        //        FormToExcel();
        //    }
        //    else
        //    {
        //        // return error - no valid forms
        //    }

        }
        */

        private dynamic GetCompetencyList(dynamic arg)
        {
            return FormMethods.FetchCompetencyList();
        }

        private dynamic ValidFilter(dynamic arg)
        {
            int userID = arg.UserID;
            bool? valid = (bool?)arg.Valid;

            return FormMethods.ValidFilter(GetFormList(userID), valid);
        }

        /*
         * Purpose:
         *  Retrieves a form from the database
         *  Paramaters:
         *  int form_id - a valid form id
         *  Returns:
         *  If succesful, a form
         *  else a null/error message
         */
        private dynamic GetAForm(dynamic arg)
        {
            int formID = arg.formID;
            CompleteForm userData;
            userData = FormStaticMethods.Fetch(formID, RetrievableDataContainers.RetrievalFlags.AllTier);
            return userData;
        }

        /*
         * Purpose:
         *  Retrieves a list of a users forms
         *  Paramaters:
         *  int userid
         *  Returns:
         *  If succesful, a list of forms - barebones data
         *  else a null/error message
         */
        private dynamic GetForms(dynamic arg)
        {
            int userID = arg.UserID;
            return GetFormList(userID);
        }

        internal List<CompleteForm> GetFormList(int id)
        {
            string cmdString = StaticSqlCommands.CMDGetSuperviseesForms;
            List<CompleteForm> Forms = new List<CompleteForm>();

            using (SqlConnection con = new SqlConnection(StaticSqlCommands.SQLConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(cmdString, con))
                {
                    cmd.Parameters.AddWithValue("@UserID", id);
                    con.Open();
                    using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (rd.HasRows)
                        {
                            while (rd.Read())
                            {
                                Forms.Add(new CompleteForm((int)rd["FormID"]));
                            }
                        }
                    }
                }
            }
            foreach (CompleteForm f in Forms)
            {
                FormStaticMethods.Fetch(f, RetrievableDataContainers.RetrievalFlags.Tier1);
            }
            return Forms;
        }

        private bool FormInsert(CompleteForm form)
        {
            bool success = true;

            using (SqlConnection con = new SqlConnection(StaticSqlCommands.SQLConnectionString))
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                SqlTransaction tran = con.BeginTransaction("Start - CreateForm");
                cmd.Connection = con;
                cmd.Transaction = tran;

                try
                {
                    cmd.CommandText = StaticSqlCommands.CMDInsertFormsTable;
                    cmd.Parameters.AddWithValue("@RelationshipID", form.RelationshipID);
                    cmd.Parameters.AddWithValue("@StartDate", form.StartDate);
                    cmd.Parameters.AddWithValue("@EndDate", form.EndDate);
                    cmd.Parameters.AddWithValue("@FormGrade", form.FormGrade.CategoryItemID);
                    if (form.Comments != null) cmd.Parameters.AddWithValue("@Comments", form.Comments);
                    else cmd.Parameters.AddWithValue("@Comments", DBNull.Value);
                    if (form.ValidFlag != null) cmd.Parameters.AddWithValue("@ValidFlag", form.ValidFlag);
                    else cmd.Parameters.AddWithValue("@ValidFlag", DBNull.Value);
                    //if (form.GroupHours > 0) cmd.Parameters.AddWithValue("@GroupHours", form.GetGroupHours().ToString());
                    if (form.GroupHours > 0) cmd.Parameters.AddWithValue("@GroupHours", form.GroupHours);
                    else cmd.Parameters.AddWithValue("@GroupHours", DBNull.Value);
                    cmd.Parameters.AddWithValue("@FormType", form.FormType.CategoryItemID);
                    var formID = cmd.ExecuteScalar();
                    cmd.Parameters.Clear();

                    if (form.SupervisionTimes != null)
                    {
                        cmd.CommandText = StaticSqlCommands.CMDInsertFormSupervisonTimes;
                        foreach (SupervisionTime t in form.SupervisionTimes)
                        {
                            cmd.Parameters.AddWithValue("@FormID", formID);
                            cmd.Parameters.AddWithValue("@SupervisionDate", t.Date);
                            //cmd.Parameters.AddWithValue("@SupervisionDuration", t.GetDuration().ToString());
                            cmd.Parameters.AddWithValue("@SupervisionDuration", t.Duration);
                            cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }

                    if (form.ExpHours != null)
                    {
                        cmd.CommandText = StaticSqlCommands.CMDInsertFormExperienceHours;
                        foreach (ExperienceHours e in form.ExpHours)
                        {
                            cmd.Parameters.AddWithValue("@FormID", formID);
                            cmd.Parameters.AddWithValue("@ItemCategoryID", e.Category.CategoryItemID);
                            //cmd.Parameters.AddWithValue("@Duration", e.GetDuration().ToString());
                            cmd.Parameters.AddWithValue("@Duration", e.Duration);
                            cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }

                    if (form.FormEvalFields != null)
                    {
                        cmd.CommandText = StaticSqlCommands.CMDInsertFormEval;
                        foreach (FormEvalField e in form.FormEvalFields)
                        {
                            cmd.Parameters.AddWithValue("@FormID", formID);
                            cmd.Parameters.AddWithValue("@EvalCategoryID", e.EvalCategory.CategoryItemID);
                            cmd.Parameters.AddWithValue("@GradeID", e.Grade.CategoryItemID);
                            cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }

                    if (form.FormCharacteristics != null)
                    {
                        cmd.CommandText = StaticSqlCommands.CMDInsertFormCharacteristics;
                        foreach (FormCharacteristic c in form.FormCharacteristics)
                        {
                            cmd.Parameters.AddWithValue("@FORMID", formID);
                            cmd.Parameters.AddWithValue("@ActivityID", c.Activity.CategoryItemID);
                            cmd.Parameters.AddWithValue("@Description", c.ActivityText);
                            cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }

                    if (form.FormCompetencies != null)
                    {
                        cmd.CommandText = StaticSqlCommands.CMDInsertFormCompetencies;
                        foreach (FormCompetency c in form.FormCompetencies)
                        {
                            cmd.Parameters.AddWithValue("@FORMID", formID);
                            cmd.Parameters.AddWithValue("@CompetencyID", c.CompetencyID);

                            if (c.EvaluationDate != default(DateTime)) cmd.Parameters.AddWithValue("@EvaluationDate", c.EvaluationDate);
                            else cmd.Parameters.AddWithValue("@EvaluationDate", DBNull.Value);

                            //if (c.GetDuration() != default(TimeSpan)) cmd.Parameters.AddWithValue("@Duration", c.GetDuration().ToString());
                            if (c.GetDuration() != default(TimeSpan)) cmd.Parameters.AddWithValue("@Duration", c.Duration);
                            else cmd.Parameters.AddWithValue("@Duration", DBNull.Value);

                            cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                    tran.Commit();
                }
                catch (Exception ex)
                {
                    tran.Rollback();
                    success = false;
                }
                return success;
            }
        }
        private dynamic CreateForm(dynamic arg)
        {
            var form = this.Bind<CompleteForm>();
            Response response = new Nancy.Response();

            bool insertResult = FormInsert(form);

            if (insertResult)
            {
                response.StatusCode = HttpStatusCode.Created;
            }
            else
            {
                response.StatusCode = HttpStatusCode.InternalServerError;
            }

            return response;

        }

        private dynamic UpdateForm(dynamic arg)
        {
            var form = this.Bind<CompleteForm>();
            string cmdString = " exec DeleteForm @FormID ";
            int result = -1;
            Response response = new Nancy.Response();
            bool insertResult = false;

            using (SqlConnection con = new SqlConnection(StaticSqlCommands.SQLConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(cmdString, con))
                {
                    cmd.Parameters.AddWithValue("@FormID", form.FormID);
                    con.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }

            if (result >= 0)
                insertResult = FormInsert(form);

            if (insertResult)
            {
                response = "good";
                response.StatusCode = HttpStatusCode.Created;
            }
            else
            {
                response = "fail";
                response.StatusCode = HttpStatusCode.InternalServerError;
            }

            return response;
        }
    }
}