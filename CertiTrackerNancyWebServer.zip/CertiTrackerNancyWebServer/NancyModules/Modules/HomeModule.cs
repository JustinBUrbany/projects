﻿/*
* Author: Morgan Loring
* Date Created: 1/16/2018
* Log:
*   1/23/2018
*       Changed message
*/

using Nancy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CertiTrackerNancyWebServer
{
    public class HomeModule : NancyModule
    {
        public HomeModule()
        {
            Get["/"] = _ =>
                                "<h1>Implemented URLs:</h1>" +
                                "<h2>Get Requests:</h2>" +
                                    "<h3>/GetUser/{UserID} - Returns an expanded user</h3>" +
                                        "<h4>Return values: </h4>" +
                                            
                                    "</br>" +
                                    "<h3>/GetRelationship/User/Supervisors/{userid} - Returns a list of a users supervisors</h3>" +
                                        "<h4>Return values: </h4>" +
                                    "<h3>/GetRelationship/RelationshipID/{RelationshipID} - Returns a base relationship</h3>" +
                                        "<h4>Return values: </h4>" +
                                    "<h3>/GetRelationship/Supervisors/Supervisees/{SupervisorID} - Returns a list of base users. List of a supervisors supervisees</h3>" +
                                        "<h4>Return values: </h4>" +
                                    "<h3>/GetSupervisor/{UserID} - Returns a supervisor user for the passed userID" +
                                        "<h4>Return values: </h4>" +
                                            "<p>HttpStatusCode.OK if successful and a supervisor data container</p>" +
                                            "<p>HttpStatusCode.InternalServerError if an error occurs </p>" +

                                    "<h3>/GetAllSupervisors - Returns a list of base users that are supervisors" +
                                        "<h4>Return values: </h4>" +
                                            "<p>HttpStatusCode.OK if successful and a list of base users</p>" +
                                            "<p>HttpStatusCode.InternalServerError if an error occurs </p>" +

                                    "</br>" + 
                                    "<h3>/Forms/Get1Form/{FormID} - Takes a formID and returns a Complete Form</h3>" +
                                    "<h3>/Forms/GetForms/{UserID} - Returns a list base forms. List of a supervisees base forms</h3>" +
                                    "<h3>/Forms/FilterForms/{UserID}/{Valid?}" +
                                    "<h3>/Forms/CompList" +
                                "</br>" + 
                                "<h2>Post Requests</h2>" +
                                    "<h3>/PostUser - Takes a json object with the data to be inserted</h3>" +
                                        "<h4>Return values: </h4>" +
                                            "<p>HttpStatusCode.Created if successful </p>" +
                                            "<p>HttpStatusCode.BadRequest if the passed email already exists in the DB </p>" +
                                            "<p>HttpStatusCode.InternalServerError if some other error occured </p>" +

                                    "<h3>/PostSupervisor - Takes a json object with the data to be inserted</h3>" +
                                        "<h4>Return values: </h4>" +
                                            "<p>HttpStatusCode.Created if successful </p>" +
                                            "<p>HttpStatusCode.BadRequest if the passed email already exists in the DB </p>" +
                                            "<p>HttpStatusCode.InternalServerError if some other error occured </p>" +
                                    "</br>" +
                                    "<h3>/Relationship/Create - Takes a json object with the data to be inserted</h3>" +
                                        "<h4>Return values: </h4>" +
                                            "<p>HttpStatusCode.Created if successful </p>" +
                                            "<p>HttpStatusCode.InternalServerError if some other error occured </p>" +
                                    "</br>" +
                                    "<h3>/Forms/Create - Takes a json object with the data to be inserted</h3>" +
                                        "<h4>Return values: </h4>" +
                                            "<p>HttpStatusCode.Created if successful </p>" +
                                            "<p>HttpStatusCode.InternalServerError if some other error occured </p>";
        }
    }
}
