﻿/*
* Author: Morgan Loring
* Date Created: 1/16/2018
* Log:
*/

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using DataContainers.Relationships;
using DataContainers.Users;
using Nancy;
using Nancy.ModelBinding;
using NancyModules;
using RetrievableDataContainers.Relationships;
using RetrievableDataContainers.Users;

namespace CertiTrackerNancyWebServer
{
    public class RelationshipModule : NancyModule
    {
        public RelationshipModule()
        {
            /// Supervisee view

            // barebones list return a supervisee's list of supervisor id, name, relationship status

            Get["/GetRelationship/User/Supervisors/{userid}"] = GetUserSupervisors;
            Get["/GetRelationship/Supervisors/Supervisees/{SupervisorID}"] = GetSupervisorsSupervisees; // returns all of the current supervisor's supervisees
                                                                                                        //list of BasicUsers
                                                                                                        // return detailed supevisor info
            Get["/GetRelationship/{SuperviseeID}/{SupervisorID}"] = GetRelationshipBothID;

            Get["/GetRelationship/RelationshipID/{RelationshipID}"] = GetBasicRelationship;

            Post["Relationship/Create"] = PostRelationship;

            //Get["/GetSupervisorDetails/{supervisor_id}"] = GetSupervisorDetails;

            ///Supervisor point of view

            // return  barebones list of supervisees names, id, relationship status

            //Get["/GetSupervisorsSupervisees/{supervisor_id}"] = GetSupervisorsSupervisees;

            // send supervisorID, a supervisee id - return supervise info

            //Get["/GetSuperviseeInfo/{granular}"] = GetSuperviseeInfo;
        }


        private dynamic GetUserSupervisors(dynamic arg)
        {
            int userID = arg.userID;
            string cmdString = StaticSqlCommands.CMDGetUsersSupervisors;
            List<SupervisorUser> supervisorIDs = new List<SupervisorUser>();

            using (SqlConnection con = new SqlConnection(StaticSqlCommands.SQLConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(cmdString, con))
                {
                    cmd.Parameters.AddWithValue("@UserID", userID);
                    con.Open();
                    using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (rd.HasRows)
                        {
                            while (rd.Read())
                            {
                                supervisorIDs.Add(new SupervisorUser((int)rd["UserID"]));
                            }
                        }
                        con.Close();
                    }
                }
            }

            foreach (SupervisorUser i in supervisorIDs)
            {
                UserStaticMethods.Fetch(i, RetrievableDataContainers.RetrievalFlags.AllTier);
            }
            return supervisorIDs;
        }

        private dynamic GetSupervisorsSupervisees(dynamic arg)
        {
            int supervisorID = arg.SupervisorID;
            string cmdString = StaticSqlCommands.CMDGetSupervisorsSupervisees;
            List<int> SuperviseesID = new List<int>();
            List<BaseUser> Supervisees = new List<BaseUser>();

            using (SqlConnection con = new SqlConnection(StaticSqlCommands.SQLConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(cmdString, con))
                {
                    cmd.Parameters.AddWithValue("@SupervisorID", supervisorID);
                    con.Open();
                    using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (rd.HasRows)
                        {
                            while (rd.Read())
                            {
                                SuperviseesID.Add((int)rd["SuperviseeID"]);
                            }
                        }
                        con.Close();
                    }
                }
            }

            foreach (int i in SuperviseesID)
            {
                Supervisees.Add(UserStaticMethods.Fetch(i, RetrievableDataContainers.RetrievalFlags.Tier1));
            }
            return Supervisees;
        }

        private dynamic GetBasicRelationship(dynamic arg)
        {
            int relationID = arg.RelationshipID;
            BaseRelationship userData;
            userData = RelationshipStaticMethods.Fetch(relationID, RetrievableDataContainers.RetrievalFlags.Tier1);
            return userData;
        }

        private dynamic GetRelationshipBothID(dynamic arg)
        {
            int idToReturn = -1;
            bool success = true;
            int superviseeID = arg.SuperviseeID;
            int supervisorID = arg.SupervisorID;
            string cmdString = StaticSqlCommands.CMDGetRelationshipBothIDs;
            Response response = new Nancy.Response();

            using (SqlConnection con = new SqlConnection(StaticSqlCommands.SQLConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(cmdString, con))
                {
                    cmd.Parameters.AddWithValue("@SuperviseeID", superviseeID);
                    cmd.Parameters.AddWithValue("@SupervisorID", supervisorID);
                    con.Open();
                    using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (rd.Read())
                        {
                            idToReturn = (int)rd["RelationshipID"];
                        }
                        else
                        {
                            success = false;
                        }
                        con.Close();
                    }
                }
            }
            response = idToReturn.ToString();
            if (success)
            {
                response.StatusCode = HttpStatusCode.OK;
            }
            else
            {
                response.StatusCode = HttpStatusCode.InternalServerError;
            }
            return response;
        }


        private dynamic PostRelationship(dynamic arg)
        {
            int result = -1;

            var relation = this.Bind<CompleteRelationship>();

            using (SqlConnection con = new SqlConnection(StaticSqlCommands.SQLConnectionString))
            {
                SqlCommand cmd = new SqlCommand(StaticSqlCommands.CMDCheckCurrentRelationships, con);
                cmd.Parameters.AddWithValue("@SupervisorID", relation.SupervisorID);
                cmd.Parameters.AddWithValue("@SuperviseeID", relation.SuperviseeID);
                con.Open();
                int numRelations = (int)cmd.ExecuteScalar();

                if (numRelations > 0)
                {
                    cmd.Parameters.Clear();
                    cmd.CommandText = StaticSqlCommands.CMDInsertRelationship;
                    cmd.Parameters.AddWithValue("@SupervisorID", relation.SupervisorID);
                    cmd.Parameters.AddWithValue("@SuperviseeID", relation.SuperviseeID);
                    if (relation.StartDate != default(DateTime)) cmd.Parameters.AddWithValue("@StartDate", relation.StartDate);
                    else cmd.Parameters.AddWithValue("@StartDate", DBNull.Value);
                    if (relation.EndDate != default(DateTime)) cmd.Parameters.AddWithValue("@EndDate", relation.EndDate);
                    else cmd.Parameters.AddWithValue("@EndDate", DBNull.Value);
                    if (relation.Comments != null) cmd.Parameters.AddWithValue("@Comments", relation.Comments);
                    else cmd.Parameters.AddWithValue("@Comments", DBNull.Value);
                    cmd.Parameters.AddWithValue("@Pending", "false");

                    try
                    {
                        result = cmd.ExecuteNonQuery();
                    }
                    catch (SqlException ex)
                    {
                        result = -1;
                    }
                }
                con.Close();
            }
            Response response;
            if (result == 1)
            {
                response = "Relationship inserted";
                response.StatusCode = HttpStatusCode.Created;
            }
            else
            {
                response = "Error";
                response.StatusCode = HttpStatusCode.InternalServerError;
            }
            return response;
        }
    }
}