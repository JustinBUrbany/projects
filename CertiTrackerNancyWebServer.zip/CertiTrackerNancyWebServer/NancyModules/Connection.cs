﻿using System;
using System.Data.SqlClient;

namespace CertiTrackerNancyWebServer
{
    public static class Connection
    {
        public static SqlConnection GetConnection()
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString =

                // This is where the database can be found.
                "Data Source=satou.cset.oit.edu" +
                ";Initial Catalog=" + "certitracker" +
                ";Integrated Security=False" +
                ";User ID=" + "StandardUser" + ";Password=" + "r6avwSDnbMZ9RJyX"
                ;
            return connection;
        }
    }
}
