﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataContainers.Forms;
using DataContainers;
using RetrievableDataContainers.Internals;
using System.Data.SqlClient;
using System.Data;


namespace NancyModuleMethods
{
    static public class FormMethods
    {
        static public List<CompleteForm> ValidFilter(List<CompleteForm> list, bool? check)
        {
            if (list != null && list.Count > 0)
            {
                List<CompleteForm> ret = new List<CompleteForm>();

                for (int x = 0; x < list.Count; ++x)
                {
                    if (list[x].ValidFlag == check)
                    {
                        ret.Add(list[x]);
                    }
                }
                list = ret;
            }
            return list;
        }
        static public List<CompleteForm> RelationshipFilter(List<CompleteForm> list, int RID)
        {
            if (list != null && list.Count != 0)
            {
                List<CompleteForm> ret = new List<CompleteForm>();
                foreach(CompleteForm x in list)
                {
                    if (x.RelationshipID == RID)
                        ret.Add(x);
                }
                list = ret;
            }
            return list;
        }

        static public ItemCategoryData[] FetchCompetencyList()
        {

            string cmdString = "SELECT * FROM TEST.ItemCategories ORDER BY CategoryItemID";
            SqlConnection con = RDCSqlConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(cmdString, con);

            con.Open();
            SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.CloseConnection | CommandBehavior.SingleResult);

            if (rd.HasRows)
            {
                int x = 0;
                List<ItemCategoryData> ret = new List<ItemCategoryData>();
                while (rd.Read())
                {
                    x = rd.GetInt32(rd.GetOrdinal("CategoryItemID"));
                    ret.Add(ItemCategoryDictionary.GetOrAdd(x));
                }
                rd.Close();
                return ret.ToArray<ItemCategoryData>();
            }
            rd.Close();

            throw new Exception("Unable to Retrieve Competency Data");
        }
    }
}
