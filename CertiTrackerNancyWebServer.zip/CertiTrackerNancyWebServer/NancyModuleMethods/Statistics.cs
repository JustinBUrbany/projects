﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataContainers.Users;

namespace NancyModuleMethods.User
{
    public static class Statistics
    {
        internal static string cmdString = "";

        public static UserStats Fetch(int id)
        {
            throw new NotImplementedException();
        }
    }
}
