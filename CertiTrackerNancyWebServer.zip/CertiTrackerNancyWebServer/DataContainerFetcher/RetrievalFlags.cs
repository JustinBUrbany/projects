﻿/*
 * Created By: Wilks
 * On: 1/15/18
 * Log:
 *  1/20/18
 *      Added Comments
 */
 using System;

namespace DataContainerFetcher
{
    /// <summary>
    /// This enum holds flags for setting retrieval level for a class implementing IRetrievable.
    /// </summary>
    [Flags]
    public enum RetrievalFlags
    {
        Tier1 = 1,
        Tier2 = 2,
        Tier3 = 4,
        AllTier = 7
    }
}
