﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataContainers.Users;

namespace DataContainerFetcher.Fetch_Method_Classes
{
    static public class UserFetchMethods
    {
        //static internal string cmdString = "SELECT U.UserID, SupervisorID AS [SID], FName, LName, Email, AreaOfInterest, Background, [Location], CertificationNumber, DateCertified, DateCompletedSupervision, DistanceSupervision FROM TEST.Users AS U JOIN TEST.Supervisors AS S ON U.UserID = S.UserID WHERE U.UserID = @id";
        static internal string cmdString = @"SELECT U.UserID, FName, LName, Email, AreaOfInterest, Background, [Location] " +
                                                "FROM TEST.Users AS U " +
                                                "WHERE U.UserID = @id";

        static internal SqlDataReader T1Fetch(BaseUser obj, RetrievalFlags flags)
        {
            SqlConnection con = ConnectionPool.GetConnection();
            using (SqlCommand cmd = new SqlCommand(cmdString, con))
            {
                cmd.Parameters.AddWithValue("@id", obj.UID); // add negative check
                con.Open();
                SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SingleRow | CommandBehavior.CloseConnection);
                rd.Read();
                    //if (!rd.Read()) // has rows method instead and drop read
                        //throw new Exception("Line_Not_Returned");
                    T1RetrievableHelper(obj, rd, flags);
                    return rd;
            }
        }

        static internal void T1RetrievableHelper(BaseUser obj, SqlDataReader rd, RetrievalFlags flags)
        {
            if (flags.HasFlag(RetrievalFlags.Tier1))
            {
                obj.Email = NullHandler.NullCheckToValidString((string)rd["Email"]);
                obj.FName = NullHandler.NullCheckToValidString((string)rd["FName"]);
                obj.LName = NullHandler.NullCheckToValidString((string)rd["LName"]);
            }
        }

        static internal SqlDataReader T2Fetch(ExpandedUser obj, RetrievalFlags flags)
        {
            SqlDataReader rd = T1Fetch(obj, flags);
            T2RetrievableHelper(obj, rd, flags);
            return rd;
        }

        static internal void T2RetrievableHelper(ExpandedUser obj, SqlDataReader rd, RetrievalFlags flags)
        {
            if (flags.HasFlag(RetrievalFlags.Tier2))
            {
                obj.AreaOfInterest = NullHandler.NullCheckToValidString((string)rd["AreaOfInterest"]);
                obj.Background = NullHandler.NullCheckToValidString((string)rd["Background"]);
                obj.Location = NullHandler.NullCheckToValidString((string)rd["Location"]);
            }
        }

        static internal void T3Fetch(SupervisorUser obj, RetrievalFlags flags)
        {
            SqlDataReader rd = T2Fetch(obj, flags);
            T3RetreivableHelper(obj, rd, flags);
        }

        static internal void T3RetreivableHelper(SupervisorUser obj, SqlDataReader rd, RetrievalFlags flags)
        {
            if (flags.HasFlag(RetrievalFlags.Tier3))
            {
                obj.SID = (int)rd["SID"];
                obj.CertificationNumber = NullHandler.NullCheckToValidString((string)rd["CertificationNumber"]);
                obj.DateCertified = (DateTime)rd["DateCertified"];
                obj.DateCompletedSupervision = (DateTime)rd["DateCompletedSupervision"];
                obj.DistanceSupervision = (bool?)rd["DistanceSupervision"];
            }
        }

        static public void BaseUser_Fetch(BaseUser obj, RetrievalFlags flags)
        {
            T1Fetch(obj, flags);
        }

        static public void ExpandedUser_Fetch(ExpandedUser obj, RetrievalFlags flags)
        {
            T2Fetch(obj, flags);
        }
        static public void SupervisorUser_Fetch(SupervisorUser obj, RetrievalFlags flags)
        {
            T3Fetch(obj, flags);
        }
    }
}
