﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataContainerFetcher
{
    static public class ConnectionPool
    {
        static internal string conString = "Data Source=satou.cset.oit.edu" +
                ";Initial Catalog=" + "certitracker" +
                ";Integrated Security=False" +
                ";User ID=" + "StandardUser" + ";Password=" + "r6avwSDnbMZ9RJyX"
                ;

        static public SqlConnection GetConnection()
        {
            return new SqlConnection(conString);
        }
    }
}
