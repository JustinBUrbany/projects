﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataContainerFetcher
{
    /// <summary>
    /// Class that holds NullToEmpty. Converts null passed to empty string, else valid string.
    /// </summary>
    static public class NullHandler
    {
        static public string NullCheckToValidString(dynamic str)
        {
            return (str == null) ? string.Empty : str;
        }
    }
}
