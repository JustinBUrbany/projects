﻿using DataContainers.Relationships;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataContainerFetcher.Fetch_Method_Classes
{
    static public class RelationshipFetchMethods
    {
        private static string cmdString = "SELECT RelationshipID, R.SupervisorID, U2.FName + ' ' + U2.LName AS SupervisorName, " +
            "R.SuperviseeID, U.FName + ' ' + U.LName AS SuperviseeName, R.StartDate, R.EndDate, R.Comments " +
            "FROM TEST.Relationships AS R JOIN TEST.Users AS U ON R.SuperviseeID = U.UserID " +
            "JOIN Test.Supervisors AS S ON R.SupervisorID = S.SupervisorID " +
            "JOIN TEST.Users AS U2 ON S.UserID = U2.UserID " +
            "WHERE RelationshipID = @id";

        static internal SqlDataReader T1Fetch(BaseRelationship obj, RetrievalFlags flags)
        {
            using (SqlConnection con = ConnectionPool.GetConnection())
            {
                using (SqlCommand cmd = new SqlCommand(cmdString, con))
                {
                    cmd.Parameters.AddWithValue("@id", obj.RelationshipID);
                    con.Open();
                    using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SingleRow | CommandBehavior.CloseConnection))
                    {
                        if (rd.HasRows && rd.Read()) // has rows method instead and drop read
                        {
                            T1RetrievableHelper(obj, rd, flags);
                        }
                        else
                            throw new Exception("DB_Return_Error");
                        return rd;
                    }
                }
            }
        }

        static internal void T1RetrievableHelper(BaseRelationship obj, SqlDataReader rd, RetrievalFlags flags)
        {
            if (flags.HasFlag(RetrievalFlags.Tier1))
            {
                obj.SupervisorID = (int)rd["SupervisorID"];
                obj.SupervisorName = NullHandler.NullCheckToValidString((string)rd["SupervisorName"]);
                obj.SuperviseeID = (int)rd["SuperviseeID"];
                obj.SuperviseeName = NullHandler.NullCheckToValidString((string)rd["SuperviseeName"]);
            }
        }

        static internal SqlDataReader T2Fetch(ExpandedRelationship obj, RetrievalFlags flags)
        {
            SqlDataReader rd = T1Fetch(obj, flags);
            T2RetrievableHelper(obj, rd, flags);
            return rd;
        }

        static internal void T2RetrievableHelper(ExpandedRelationship obj, SqlDataReader rd, RetrievalFlags flags)
        {
            if (flags.HasFlag(RetrievalFlags.Tier2))
            {
                obj.StartDate = (DateTime)rd["StartDate"];
                obj.EndDate = (DateTime)rd["EndDate"];
            }
        }

        static internal void T3Fetch(CompleteRelationship obj, RetrievalFlags flags)
        {
            SqlDataReader rd = T2Fetch(obj, flags);
            T3RetreivableHelper(obj, rd, flags);
        }

        static internal void T3RetreivableHelper(CompleteRelationship obj, SqlDataReader rd, RetrievalFlags flags)
        {
            if (flags.HasFlag(RetrievalFlags.Tier3))
            {
                obj.Comments = NullHandler.NullCheckToValidString((string)rd["Comments"]);
            }
        }

        static public void BaseRelationship_Fetch(BaseRelationship obj, RetrievalFlags flags)
        {
            T1Fetch(obj, flags);
        }

        static public void ExpandedRelationship_Fetch(ExpandedRelationship obj, RetrievalFlags flags)
        {
            T2Fetch(obj, flags);
        }

        static public void CompleteRelationship_Fetch(CompleteRelationship obj, RetrievalFlags flags)
        {
            T3Fetch(obj, flags);
        }
    }
}
